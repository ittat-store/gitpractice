#include<stdio.h>
static int x=5;
int y=&x;
main()
{
printf("%d\n",sizeof(""));
}


#include<stdio.h>
main()
{
int i=10,j=2;
printf("%d\n",printf("%d %d",i,j));
}

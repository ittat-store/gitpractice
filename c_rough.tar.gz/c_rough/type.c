#include<stdio.h>
main()
{
int a=3;
float b=2.5;
int c=a/b;
printf("%d\n",c);
}

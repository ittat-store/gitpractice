#include<stdio.h>
int main()
{
unsigned char c=255;
int i=~c;
printf("%d",i);
}

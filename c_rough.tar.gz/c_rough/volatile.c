#include<stdio.h>
main()
{
int const a=10;
printf("%d\n",a);
}


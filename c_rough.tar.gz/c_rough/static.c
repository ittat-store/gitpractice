#include<stdio.h>
int x=10;
static int y=x;
main()
{
printf("%d\n",y);
}

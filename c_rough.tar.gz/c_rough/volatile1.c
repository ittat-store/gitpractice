#include<stdio.h>
main()
{
volatile int a=10;
printf("%d\n",a);
}


#include<stdio.h>
main()
{
//int x=y=0;
int a,b,c=(1,2,3);
printf("%d %d %d\n",a,b,c);
}

#include<stdio.h>
main()
{
int a=1;
switch(a)
{
case a: printf("hi");
default:printf(......);
}
}

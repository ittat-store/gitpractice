/*#include<stdio.h>
int kee()
{
printf("hi keerthi\n");
}
int _keerthi()
{
printf("hi qualcomm\n");
kee();
exit(0);
}*/

#include<stdio.h> 
#include<stdlib.h> 

// entry point function 
int nomain()
{
        puts("Geeksforgeeks");
        return 0;
}

 

void _start()
{ 

	// calling entry point 
	printf("keerthi\n");
	nomain(); 
	exit(0); 
} 

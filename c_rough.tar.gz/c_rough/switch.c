#include<stdio.h>
main()
{
int a;
printf("enter choice\n");
scanf("%d",&a);
switch(a)
{
case 1: printf("keerthi");
case 2:printf("kumari");
default:printf("qualcomm");
}
}

function CinBase64(){
	
}

CinBase64._base64map =[ 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd',
			'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '-', '_' ];

CinBase64._base64salt = [ -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
			-1, -1, -1, -1, -1, -1, -1, 62, -1, -1, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21,
			22, 23, 24, 25, -1, -1, -1, -1, 63, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1, -1, -1 ];
CinBase64._padding = ';'			
CinBase64.encode = function(s){
	var bytes = s;

	if(typeof s === 'string'){
		bytes = JIOUtils.getBytes(s);
	}

    var length = bytes.length;
	var groupCount = parseInt(length / 3);
	var paddingBytes = length % 3;
	var paddingLength = length - paddingBytes;
	var resultLen = 4 * parseInt((length + 2) / 3);
	var result = new StringBuffer();
	// Translate all full groups from byte array elements to Base64
	var index = 0;
	for (var i = 0; i < groupCount; i++) {
		var byte0 = bytes[index++] & 0xff;
		var byte1 = bytes[index++] & 0xff;
		var byte2 = bytes[index++] & 0xff;
		result.append(CinBase64._base64map[byte0 >> 2]);
		result.append(CinBase64._base64map[(byte0 << 4) & 0x3f | (byte1 >> 4)]);
		result.append(CinBase64._base64map[(byte1 << 2) & 0x3f | (byte2 >> 6)]);
		result.append(CinBase64._base64map[byte2 & 0x3f]);
	}

	if (paddingBytes == 1) {
		result.append(CinBase64._base64map[(bytes[paddingLength] & 0xff) >> 2 & 0x3f]);
		result.append(CinBase64._base64map[((bytes[paddingLength] & 0xff) << 4) & 0x3f]);
		result.append(CinBase64._padding);
		result.append(CinBase64._padding);
	}
	if (paddingBytes == 2) {
		result.append(CinBase64._base64map[(bytes[paddingLength] & 0xff) >> 2 & 0x3f]);
		result.append(CinBase64._base64map[((bytes[paddingLength] & 0xff) << 4) & 0x3f | ((bytes[paddingLength + 1] & 0xff) >> 4) & 0x3f]);
		result.append(CinBase64._base64map[(bytes[paddingLength + 1] << 2) & 0x3f]);
		result.append(CinBase64._padding);
	}
	return result.toString();
}

CinBase64.decode = function(s){
	
	if(!s){
		return new Array();
	}

    var sLen = s.length;
	if (sLen % 4 != 0)
		throw new Error("String length must be a multiple of four.");
	var groupCount = parseInt(sLen / 4);
	var bytes = s;
	if(typeof s !== 'string'){
		s = JIOUtils.toString(s);
	}

	if(typeof s === 'string'){
		bytes = JIOUtils.getBytes(s);
	}

	var missingBytes = 0;
	var numFullGroups = groupCount;
	if (sLen != 0) {
		if (s.charCodeAt(sLen - 1) == CinBase64._padding) {
			missingBytes++;
			numFullGroups--;
		}
		if (s.charCodeAt(sLen - 2) == CinBase64._padding)
			missingBytes++;
	}

	result = new Array();

	var index = 0, out = 0;
	for (var i = 0; i < numFullGroups; i++) {
		 ch0 = CinBase64.getByte(CinBase64.base64Salt(bytes[index++],i));
		 ch1 = CinBase64.getByte(CinBase64.base64Salt(bytes[index++],i));
		 ch2 = CinBase64.getByte(CinBase64.base64Salt(bytes[index++],i));
		 ch3 = CinBase64.getByte(CinBase64.base64Salt(bytes[index++],i));
		result[out++] =  CinBase64.getByte(((ch0 << 2) | (ch1 >> 4)));
		result[out++] =  CinBase64.getByte(((ch1 << 4) | (ch2 >> 2)));
		result[out++] =  CinBase64.getByte(((ch2 << 6) | ch3));
	}

	if (missingBytes != 0) {
		 ch0 = CinBase64.getByte(CinBase64.base64Salt(bytes[index++]));
		 ch1 = CinBase64.getByte(CinBase64.base64Salt(bytes[index++]));
		result[out++] =  CinBase64.getByte(((ch0 << 2) | (ch1 >> 4)));

		if (missingBytes == 1) {
			ch2 = CinBase64.getByte(CinBase64.base64Salt(bytes[index++]));
			result[out++] = CinBase64.getByte(((ch1 << 4) | (ch2 >> 2)));
		}
	}
	return result;
}

CinBase64.getByte = function(i){
	var array = new Int8Array([i]);
	return array[0];
}

CinBase64.base64Salt = function(intValue,i) {
	//Converting long to byte
    var byte = intValue;

	var result = CinBase64._base64salt[byte];
	if (result < 0){
		return 0;
		//throw new Error("Illegal character ");
	}
	return result;
}

CinBase64.base64MobileNum = function(mobile) {
	return CinBase64.encode(CinHelper.long2Bytes(mobile));
}

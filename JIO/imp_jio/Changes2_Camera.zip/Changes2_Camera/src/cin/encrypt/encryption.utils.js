function EncryptionUtils () {
}

EncryptionUtils.convertUint8ArrayToWordArray = function(u8Array){
	if(!u8Array){
        return;
    }
	var words = [], i = 0, len = u8Array.byteLength;

	while (i < len) {
		words.push(
			(u8Array[i++] << 24) |
			(u8Array[i++] << 16) |
			(u8Array[i++] << 8)  |
			(u8Array[i++])
		);
	}

	return {
		sigBytes: words.length * 4,
		words: words
	};
};

EncryptionUtils.getUserPassword = function(password){
	// var hexHash = SparkMD5.hash('Hi there');        // hex hash
	// var rawHash = SparkMD5.hash('Hi there', true);  // OR raw hash (binary string)
	return password;
};

EncryptionUtils.numberOfLeadingZeros = function(i) {
	 if (i == 0)
	    return 64;
	var n = 1;
	var x = (i >>> 32);
	if (x == 0) { n += 32; x = i; }
	if (x >>> 16 == 0) { n += 16; x <<= 16; }
	if (x >>> 24 == 0) { n +=  8; x <<=  8; }
	if (x >>> 28 == 0) { n +=  4; x <<=  4; }
	if (x >>> 30 == 0) { n +=  2; x <<=  2; }
	n -= x >>> 31;
	return n;
};

EncryptionUtils.encrypt = function(message, uuid){
	var words = CryptoJS.enc.Utf16.parse(message); 
	var token = UserModel.getInstance().getToken();
	var key = new Array();

	for(index=0;index<8;index++){
		key[index] = token[index];
		key[8+index] = uuid[index];
	}

	key = EncryptionUtils.convertUint8ArrayToWordArray(new Uint8Array(key));

	var options = { mode: CryptoJS.mode.ECB };  
	// var msgBytes = JIOUtil.getBytes(message);
	// debugger;
	var encrypted = CryptoJS.AES.encrypt(message, key, options);  
	var ciphertext = encrypted.ciphertext;
	var encryptedByteArray = EncryptionUtils.wordToByteArray(ciphertext.words);
	// var bytesArray = CryptoJS.enc.Utf16.parse(message);
   	return new Int8Array(encryptedByteArray);
	// return JIOUtils.utf16to8(message);
};

EncryptionUtils.encryptForEmoji = function(message, uuid){
	var words = CryptoJS.enc.Utf16.parse(message); 
	var token = UserModel.getInstance().getToken();
	var key = new Array();

	for(index=0;index<8;index++){
		key[index] = token[index];
		key[8+index] = uuid[index];
	}

	key = EncryptionUtils.convertUint8ArrayToWordArray(new Uint8Array(key));

	var options = { mode: CryptoJS.mode.ECB };    
			
	cipherParams = CryptoJS.lib.CipherParams.create({
		ciphertext: words,
	});
	
	var encrypted = CryptoJS.AES.encrypt(words, key, options); 
	var hex = JIOUtils.toByteArray(encrypted.toString(CryptoJS.enc.Hex));
	var ciphertext = encrypted.ciphertext;
	var encryptedByteArray = EncryptionUtils.wordToByteArray(ciphertext.words);

   	return new Int8Array(encryptedByteArray);
} 

EncryptionUtils.encryptForEmojios = function(message, uuid){
	// debugger;
	// var token = UserModel.getInstance().getToken();
	// var key = new Array();

	// for(index=0;index<8;index++){
	// 	key[index] = token[index];
	// 	key[8+index] = uuid[index];
	// }

	// key = EncryptionUtils.convertUint8ArrayToWordArray(new Uint8Array(key));

	// var options = { mode: CryptoJS.mode.ECB };    
	
	var incomingArray = new Array();
	// for(var msgIndex = 0; msgIndex<message.length;msgIndex++){
	// 	var currentArray = new Array();
	// 	if(message[msgIndex].t && message[msgIndex].t =='e'){
	// 		// TODO
	// 		var emojiHexString = message[msgIndex].v;
	// 		if(emojiHexString){
	// 			emojiHexString = emojiHexString.split("_");
	// 			for(var emjoiIndex=0; emjoiIndex<emojiHexString.length; emjoiIndex++){
	// 				// emojiHexString = "0x"+emojiHexString;
	// 				// var val = parseInt("0x"+emojiHexString[emjoiIndex]);
	// 				// emojiHexString = emojiHexString.replace("_","");
	// 				// currentArray = Array.prototype.slice.call(JIOUtils.long2Bytes(val));
	// 				currentArray = JIOUtils.toByteArray(emojiHexString[emjoiIndex]);
	// 			}
	// 		}
	// 	}else if(message[msgIndex].t && message[msgIndex].t =='s'){
	// 		// TODO
	// 		var chatMsg = message[msgIndex].v;
	// 		if(chatMsg){
	// 			currentArray = JIOUtils.getBytes(chatMsg)
	// 		}
			
	// 	}
	// 	incomingArray=incomingArray.concat(currentArray);
	// }

	// var convertedArrary = new Uint8Array(incomingArray);
	
	// var str = EncryptionUtils.convertUint8ArrayToWordArray(convertedArrary);	
	// var array = CryptoJS.lib.WordArray.create(str.words, convertedArrary.byteLength);
	
	// cipherParams = CryptoJS.lib.CipherParams.create({
	// 	ciphertext: array,
	// });

	// var options = { mode: CryptoJS.mode.ECB };  
	var int8Array;
	for(var index = 0;index<message.length;index++){
		int8Array = JIOUtils.long2Bytes(message.charCodeAt(index));
		int8Array = Array.prototype.slice.call(int8Array);
		incomingArray = incomingArray.concat(int8Array);
	}
	var data = EncryptionUtils.toUTF8Array(message);
	var d = EncryptionUtils.toUTF8Arrays(message);
	// var encrypted = CryptoJS.AES.encrypt(cipherParams, key, options);  	
	
	// var options = { mode: CryptoJS.mode.ECB };  
	// var msgBytes = JIOUtil.getBytes(message);
	// debugger;
	// var encrypted = CryptoJS.AES.encrypt(message, key, options);  
	// var ciphertext = encrypted.ciphertext;
	// var encryptedByteArray = EncryptionUtils.wordToByteArray(ciphertext.words);
	// var bytesArray = CryptoJS.enc.Utf16.parse(message);
   	return new Int8Array(incomingArray);
	// return JIOUtils.utf16to8(message);
};
EncryptionUtils.toUTF8Array = function(str) {
    var utf8 = [];
    for (var i=0; i < str.length; i++) {
        var charcode = str.charCodeAt(i);
        if (charcode < 0x80) utf8.push(charcode);
        else if (charcode < 0x800) {
            utf8.push(0xc0 | (charcode >> 6), 
                      0x80 | (charcode & 0x3f));
        }
        else if (charcode < 0xd800 || charcode >= 0xe000) {
            utf8.push(0xe0 | (charcode >> 12), 
                      0x80 | ((charcode>>6) & 0x3f), 
                      0x80 | (charcode & 0x3f));
        }
        // surrogate pair
        else {
            i++;
            // UTF-16 encodes 0x10000-0x10FFFF by
            // subtracting 0x10000 and splitting the
            // 20 bits of 0x0-0xFFFFF into two halves
            charcode = 0x10000 + (((charcode & 0x3ff)<<10)
                      | (str.charCodeAt(i) & 0x3ff))
            utf8.push(0xf0 | (charcode >>18), 
                      0x80 | ((charcode>>12) & 0x3f), 
                      0x80 | ((charcode>>6) & 0x3f), 
                      0x80 | (charcode & 0x3f));
        }
    }
    return utf8;
}
EncryptionUtils.toUTF8Arrays = function(str){
  var out = [], p = 0;
  for (var i = 0; i < str.length; i++) {
    var c = str.charCodeAt(i);
    if (c < 128) {
      out[p++] = c;
    } else if (c < 2048) {
      out[p++] = (c >> 6) | 192;
      out[p++] = (c & 63) | 128;
    } else if (
        ((c & 0xFC00) == 0xD800) && (i + 1) < str.length &&
        ((str.charCodeAt(i + 1) & 0xFC00) == 0xDC00)) {
      // Surrogate Pair
      c = 0x10000 + ((c & 0x03FF) << 10) + (str.charCodeAt(++i) & 0x03FF);
      out[p++] = (c >> 18) | 240;
      out[p++] = ((c >> 12) & 63) | 128;
      out[p++] = ((c >> 6) & 63) | 128;
      out[p++] = (c & 63) | 128;
    } else {
      out[p++] = (c >> 12) | 224;
      out[p++] = ((c >> 6) & 63) | 128;
      out[p++] = (c & 63) | 128;
    }
  }
  return out;
}
EncryptionUtils.wordToByteArray = function(wordArray) {
    var byteArray = [], word, i, j;
    for (i = 0; i < wordArray.length; ++i) {
        word = wordArray[i];
        for (j = 3; j >= 0; --j) {
            byteArray.push((word >> 8 * j) & 0xFF);
        }
    }
    return byteArray;
};

EncryptionUtils.decrypt = function(incomingArray, uuid, token){
	//If no uuid.
	if(uuid === null || !uuid){
		return incomingArray;
	}

	var key = new Array();
	if(!token || token.length === 0){
		token = UserModel.getInstance().getToken();
	}

	for(index=0; index<8; index++){
		key[index] = token[index];
		key[8+index] = uuid[index];
	}

	key = EncryptionUtils.convertUint8ArrayToWordArray(new Uint8Array(key));
	var options = { mode: CryptoJS.mode.ECB };    
	var convertedArrary = new Uint8Array(incomingArray);
	var str = EncryptionUtils.convertUint8ArrayToWordArray(convertedArrary);	
	var array = CryptoJS.lib.WordArray.create(str.words, convertedArrary.byteLength);
	cipherParams = CryptoJS.lib.CipherParams.create({
		ciphertext: array,
	});
	var decrypted = CryptoJS.AES.decrypt(cipherParams, key, options);  	
	return decrypted.toString(CryptoJS.enc.Utf8); 
};

EncryptionUtils.decryptBytes = function(incomingArray, uuid, token){
	//If no uuid.

	if(uuid === null || !uuid){
		return incomingArray;
	}

	var key = new Array();
	if(!token || token.length === 0){
		token = UserModel.getInstance().getToken();
	}

	for(index=0; index<8; index++){
		key[index] = token[index];
		key[8+index] = uuid[index];
	}

	key = EncryptionUtils.convertUint8ArrayToWordArray(new Uint8Array(key));
	var options = { mode: CryptoJS.mode.ECB };    
	var convertedArrary = new Uint8Array(incomingArray);
	var str = EncryptionUtils.convertUint8ArrayToWordArray(convertedArrary);	
	var array = CryptoJS.lib.WordArray.create(str.words, convertedArrary.byteLength);
	cipherParams = CryptoJS.lib.CipherParams.create({
		ciphertext: array,
	});
	var decrypted = CryptoJS.AES.decrypt(cipherParams, key, options);
	return new Int8Array(EncryptionUtils.wordToByteArray(decrypted.words)); 
};
EncryptionUtils.decryptNotification = function(incomingArray, uuid, token){
	//If no uuid.
	if(uuid === null || !uuid){
		return incomingArray;
	}

	var key = new Array();
	if(!token || token.length === 0){
		token = UserModel.getInstance().getToken();
	}

	for(index=0; index<8; index++){
		key[index] = token[index];
		key[8+index] = uuid[index];
	}

	key = EncryptionUtils.convertUint8ArrayToWordArray(new Uint8Array(key));
	var options = { mode: CryptoJS.mode.ECB };    
	var convertedArrary = new Uint8Array(incomingArray);
	var str = EncryptionUtils.convertUint8ArrayToWordArray(convertedArrary);	
	var array = CryptoJS.lib.WordArray.create(str.words, convertedArrary.byteLength);
	cipherParams = CryptoJS.lib.CipherParams.create({
		ciphertext: array,
	});
	var decrypted = CryptoJS.AES.decrypt(cipherParams, key, options);  	
	return  plainText = decrypted.toString(CryptoJS.enc.Utf8);
};
EncryptionUtils.getRandomString = function(numberOfChars){
	if(!numberOfChars){
		numberOfChars = 18;
	}
 	var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    for( var index=0; index < numberOfChars; index++ ){
        text += possible.charAt(Math.floor(Math.random() * possible.length));
	}
    return text;
}

EncryptionUtils.encryptFile = function(fileData){
	// debugger;
	var keySize = 256;
	var ivSize = 128;
	// var iterations = 5;
	var randomStr = EncryptionUtils.getRandomString();
  	var salt = CryptoJS.lib.WordArray.random(ivSize/8);
	var password = SparkMD5.hash(randomStr+'|jioChat|jqHZudy88gYRrsSgylFa');
	// debugger;
  	password = JIOUtils.getBytes(password).slice(-32);

	var key = EncryptionUtils.convertUint8ArrayToWordArray(new Uint8Array(password));
  	var iv = CryptoJS.lib.WordArray.random(128/8);
	var encrypted = CryptoJS.AES.encrypt(fileData, key, { 
		iv: iv, 
		padding: CryptoJS.pad.Pkcs7,
		mode: CryptoJS.mode.CBC
	});
  	var transitmessage = randomStr + salt.toString()+ iv.toString() + encrypted.toString();
  	return transitmessage;
}

EncryptionUtils.deCryptFile = function(transitmessage) {
	try{
		var keySize = 256;
		var ivSize = 128;

		var randomStr = transitmessage.substr(0,18);
		var password = SparkMD5.hash(randomStr+'|jioChat|jqHZudy88gYRrsSgylFa');
		
		var salt = CryptoJS.enc.Hex.parse(transitmessage.substr(18, 32));
		var iv = CryptoJS.enc.Hex.parse(transitmessage.substr(50, 32))
		var encrypted = transitmessage.substring(82);
	
		password = JIOUtils.getBytes(password).slice(-32);
		var key = EncryptionUtils.convertUint8ArrayToWordArray(new Uint8Array(password));
		var decrypted = CryptoJS.AES.decrypt(encrypted, key, { 
			iv: iv, 
			padding: CryptoJS.pad.Pkcs7,
			mode: CryptoJS.mode.CBC
		});
		return decrypted.toString(CryptoJS.enc.Utf8);
	}catch(e){
		console.log("***** Decryption failed....");
		return "";
	}
}

EncryptionUtils.getHashCode = function(str, asString, seed){
	if(asString==undefined || asString==null){
		asString=true;
	}

    var i, l,
	hval = (seed === undefined) ? 0x800c9dc5 : seed; // 0x811c9dc5

    for (i = 0, l = str.length; i < l; i++) {
        hval ^= str.charCodeAt(i);
        hval += (hval << 1) + (hval << 4) + (hval << 7) + (hval << 8) + (hval << 24);
    }
    if(asString){
        // Convert to 8 digit hex string
        return ("0000000" + (hval >>> 0).toString(16)).substr(-8);
    }
	return hval >>> 0;
}

EncryptionUtils.getSeqID = function(str, numberOfChars){
	//As per android device id, ANDROID_ID is "64-bit number (as a hex string)". 
	//Each hex digit represents 4 bits, so it will be a 16 character String, So I am taking last 16 chars.
	if(numberOfChars==undefined|| numberOfChars==null || numberOfChars==0){
		numberOfChars=-16;
	}
	var hashCode = String(EncryptionUtils.getHashCode(str));
	var md5Hash = CryptoJS.MD5(hashCode).toString();
	var res = md5Hash.substring(6, 6+8)+md5Hash.substring(23, 23+8);
	console.log("[Sec] Final Hash", res);
	res = md5Hash.substr(numberOfChars);
	console.log("[Sec] Hash", res);
	return res;
}
function CINRequestConts() {
}

//CINRequestConts.USER_ID = [58,44,29,-77,1];
// CINRequestConts.USER_ID = [97,41,29,-77,1];

// For Web
CINRequestConts.PLATFORM_TYPE_ANDROID = CinBase64.getByte(0X02);
CINRequestConts.PLATFORM_TYPE_TIZEN = CinBase64.getByte(0X05);
CINRequestConts.PLATFORM_TYPE_PC = CinBase64.getByte(0X08);
CINRequestConts.PLATFORM_TYPE_WEB = CinBase64.getByte(0X0A);
CINRequestConts.PLATFORM_TYPE_UWP = CinBase64.getByte(0X06);
CINRequestConts.PLATFORM_TYPE_WP = CinBase64.getByte(0X09);
CINRequestConts.PLATFORM_TYPE_FEATUREPHONE = CinBase64.getByte(0X0B);

CINRequestConts.PLATFORM_TYPE = CINRequestConts.PLATFORM_TYPE_FEATUREPHONE;
CINRequestConts.PLATFORM_VERSION = "1.0.0";
CINRequestConts.PLATFORM_CAPABILITY = 1 + 4 + 8 + 32 + 128 + 256 + 512 + 2048 + 16384 + 65536 + 524288;//+524288 for clearMessageCount
// CINRequestConts.PLATFORM_CAPABILITY =  1+4+8+32+128+256+512+2048+16384+65536;
//CINRequestConts.PLATFORM_CAPABILITY =  1+4+8+32+128+512+2048+16384+65536;


// For Android 
// CINRequestConts.PLATFORM_TYPE =  CinBase64.getByte(0x02);
// CINRequestConts.PLATFORM_VERSION = "2.1.7";
// CINRequestConts.PLATFORM_CAPABILITY =  1+4+8+32+128+512+2048+16384;

CINRequestConts.REQ_METHOD = CinBase64.getByte(0x01);
CINRequestConts.RES_METHOD = CinBase64.getByte(0x02);
CINRequestConts.REQ_EVENT = CinBase64.getByte(0x0D);
CINRequestConts.DISCRIPTION = CinBase64.getByte(0x17);
CINRequestConts.HEADER_TYPE_OEM = CinBase64.getByte(0x13);
CINRequestConts.NO_METHOD = 255;
CINRequestConts.EVENT_PUBLIC_SEND_MSG = CinBase64.getByte(0x50);

CINRequestConts.EVENT_TAKE_CARD = CinBase64.getByte(0x01);
CINRequestConts.EVENT_UPDATE_CARD = CinBase64.getByte(0x08);
CINRequestConts.EVENT_UPLOAD_PORTRAIT_INDEX = CinBase64.getByte(0x09);
CINRequestConts.EVENT_DOWNLOAD_AVATAR_THUMB = CinBase64.getByte(0x0A);
CINRequestConts.EVENT_DLETE_AVATAR = CinBase64.getByte(0x11);
CINRequestConts.EVENT_UPDATE_GROUP_PORTRAIT = CinBase64.getByte(0x16);
CINRequestConts.EVENT_GET_GROUP_PORTRAIT = CinBase64.getByte(0x17);


CINRequestConts.HEADER_PHONE_NUMBER = CinBase64.getByte(0x41);
CINRequestConts.HEADER_RCS_NAME = CinBase64.getByte(0x42);
CINRequestConts.HEADER_RCS_MOOD = CinBase64.getByte(0x43);
CINRequestConts.HEADER_RCS_EXPRESSION = CinBase64.getByte(0x44);
CINRequestConts.HEADER_RCS_GENDER = CinBase64.getByte(0x45);
CINRequestConts.HEADER_RCS_PORTRAIT_ID = CinBase64.getByte(0x46);

CINRequestConts.SERVICE = CinBase64.getByte(0x01);
CINRequestConts.MESSAGE = CinBase64.getByte(0x02);
CINRequestConts.REPLY = CinBase64.getByte(0x03);
CINRequestConts.READ_REPLY = CinBase64.getByte(0x04);
CINRequestConts.KEEP_ALIVE = CinBase64.getByte(0x05);
CINRequestConts.LOGON = CinBase64.getByte(0x07);
CINRequestConts.NOTIFY = CinBase64.getByte(0x0A);
CINRequestConts.ASK = CinBase64.getByte(0x0B);
CINRequestConts.TYPING = CinBase64.getByte(0x0C);
CINRequestConts.TAKE = CinBase64.getByte(0x0F);
CINRequestConts.GROUP = CinBase64.getByte(0x10);
CINRequestConts.GROUPMESSAGE = CinBase64.getByte(0x11);
CINRequestConts.DATA = CinBase64.getByte(0x15);
CINRequestConts.VERIFY = CinBase64.getByte(0x17);
CINRequestConts.REPORT = CinBase64.getByte(0x19);
CINRequestConts.PHONEBOOK = CinBase64.getByte(0x1A);
CINRequestConts.EMOTICON = CinBase64.getByte(0x1B);
CINRequestConts.VIDEO = CinBase64.getByte(0x1C);
CINRequestConts.ROBOTMESSAGE = CinBase64.getByte(0x20);
CINRequestConts.DPSERVICE = CinBase64.getByte(0x30);
CINRequestConts.DPSUB = CinBase64.getByte(0x31);
CINRequestConts.DPUNSUB = CinBase64.getByte(0x32);
CINRequestConts.DPNOTIFY = CinBase64.getByte(0x33);
CINRequestConts.DPTAKE = CinBase64.getByte(0x34);
CINRequestConts.SOCIAL = CinBase64.getByte(0x62);
CINRequestConts.SOCIALNOTIFY = CinBase64.getByte(0x64);
CINRequestConts.UNKNOWN = CinBase64.getByte(0X7E);
CINRequestConts.NETWORKSTATE = CinBase64.getByte(0X7D);
CINRequestConts.SESSION = CinBase64.getByte(0x7C);
CINRequestConts.CONTACT = CinBase64.getByte(0x80);
CINRequestConts.EVENT_LAST_LOGON_TIME = CinBase64.getByte(0x02);
CINRequestConts.PORTRAITID = CinBase64.getByte(0x02);
CINRequestConts.CHANGE_CONTACT = CinBase64.getByte(0x10);

CINRequestConts.RMC = CinBase64.getByte(0x21);
CINRequestConts.TRACK = CinBase64.getByte(0x23);
CINRequestConts.IDAMTOKEN = CinBase64.getByte(0x53);
CINRequestConts.CONTACT_PERMISSION = CinBase64.getByte(0x88);

CINRequestConts.JM_TRANSACTION = CinBase64.getByte(0x40);
CINRequestConts.JM_SIGNUP = CinBase64.getByte(0x41);
CINRequestConts.JM_LOADMONEY = CinBase64.getByte(0x42);

//FOR LOGON REQUEST
CINRequestConts.EVENT_CHALLENGE = CinBase64.getByte(0x01);
CINRequestConts.EVENT_LOGON = CinBase64.getByte(0x02);
CINRequestConts.EVENT_CHECKCREDENTIAL = CinBase64.getByte(0x03);
CINRequestConts.EVENT_KEEP_ALIVE = CinBase64.getByte(0x04);
CINRequestConts.EVENT_LOGOFF = CinBase64.getByte(0x05);
CINRequestConts.EVENT_KICK_OTHER_CLIENT = CinBase64.getByte(0x08);
CINRequestConts.EVENT_RECONNECT = CinBase64.getByte(0x7F);

//FOR PHONEBOOK REQUEST
CINRequestConts.EVENT_PHONEBOOK_UPLOAD = CinBase64.getByte(0x01);
CINRequestConts.EVENT_PHONEBOOK_DOWNLOAD = CinBase64.getByte(0x02);
CINRequestConts.PHONEBOOK_VERSION = CinBase64.getByte(0x05);

//FOR GROUP EVENTS
CINRequestConts.EVENT_UPDATE_GROUP = CinBase64.getByte(0x01);
CINRequestConts.EVENT_INVITE_GROUP = CinBase64.getByte(0x02);
CINRequestConts.EVENT_QUIT_GROUP = CinBase64.getByte(0x03);
CINRequestConts.EVENT_INITIALIZE = CinBase64.getByte(0x04);
CINRequestConts.EVENT_CREATE_GROUP = CinBase64.getByte(0x05);
CINRequestConts.EVENT_UPDATE_GROUP_SET = CinBase64.getByte(0x06);
CINRequestConts.EVENT_GET_GROUP_INFO = CinBase64.getByte(0x07);
CINRequestConts.EVENT_UPDATE_GROUP_MESSAGE_ACCEPT_SET = CinBase64.getByte(0x09);
CINRequestConts.EVENT_GET_GROUP_LIST = CinBase64.getByte(0x20);
CINRequestConts.EVENT_TRANSFER_GROUP_ADMIN = CinBase64.getByte(0x22);
CINRequestConts.EVENT_ENTER_GROUP = CinBase64.getByte(0x08);
CINRequestConts.EVENT_CLEAR_RECORDS = CinBase64.getByte(0x0B);
CINRequestConts.EVENT_GET_GROUP_PROFILE = CinBase64.getByte(0x21);


//GROUP USER INFO
CINRequestConts.GROUP_USER_USERID = CinBase64.getByte(0x01);
CINRequestConts.GROUP_USER_NAME = CinBase64.getByte(0x02);

//FOR CONTACT EVENTS
CINRequestConts.INVITE_VIA_EMAIL = CinBase64.getByte(0X03);
CINRequestConts.INVITE_VIA_SMS = CinBase64.getByte(0x04);

CINRequestConts.HEADER_TYPE_CLOUD_CONTACT_TYPE = CinBase64.getByte(0x05);
CINRequestConts.HEADER_TYPE_CONTACT_VERSION = CinBase64.getByte(0x06);
CINRequestConts.HEADER_TYPE_REVERSE_CONTACT_VERSION = CinBase64.getByte(0x07);
CINRequestConts.HEADER_TYPE_SWITCH_VALUE = CinBase64.getByte(0x08);
CINRequestConts.HEADER_TYPE_GROUP_MAX_COUNT = CinBase64.getByte(0x09);
CINRequestConts.HEADER_TYPE_DND_START = CinBase64.getByte(0x0A);
CINRequestConts.HEADER_TYPE_DND_INTERVAL = CinBase64.getByte(0x0B);
CINRequestConts.HEADER_TYPE_BLOCK_LIST_VERSION = CinBase64.getByte(0x0D);
CINRequestConts.HEADER_TYPE_SELECTED_MSG_VERSION = CinBase64.getByte(0x0F);
CINRequestConts.HEADER_TYPE_EMOTICON_LIST_VERSION = CinBase64.getByte(0x13);
CINRequestConts.HEADER_TYPE_CHANNEL_LIST_VERSION = CinBase64.getByte(0x15);
CINRequestConts.HEADER_TYPE_PUBLICPLATFORM_RECOMMENDLIST_VERSION = CinBase64.getByte(0x16);
CINRequestConts.HEADER_TYPE_JAA_SWITCH = CinBase64.getByte(0x17);


CINRequestConts.FROM = CinBase64.getByte(0x01);
CINRequestConts.TO = CinBase64.getByte(0x02);
CINRequestConts.CALLID = CinBase64.getByte(0x03);
CINRequestConts.CSEQUENCE = CinBase64.getByte(0x04);
CINRequestConts.MESSAGEID = CinBase64.getByte(0x05);
CINRequestConts.DATETIME = CinBase64.getByte(0x06);
CINRequestConts.TOKEN = CinBase64.getByte(0x07);
CINRequestConts.PASSWORD = CinBase64.getByte(0x08);
CINRequestConts.CREDENTIAL = CinBase64.getByte(0x09);
CINRequestConts.TYPE = CinBase64.getByte(0x0A);
CINRequestConts.MOBILENO = CinBase64.getByte(0x0B);
CINRequestConts.EXPIRE = CinBase64.getByte(0x0C);
CINRequestConts.EVENT = CinBase64.getByte(0x0D);
CINRequestConts.ROUTE = CinBase64.getByte(0x0E);

CINRequestConts.TYPE_TEXT = CinBase64.getByte(0x7F);
CINRequestConts.TYPE_IMAGE = CinBase64.getByte(0x00);
CINRequestConts.TYPE_VOICE = CinBase64.getByte(0x01);
CINRequestConts.TYPE_FILE = CinBase64.getByte(0x02);
CINRequestConts.TYPE_VIDEO = CinBase64.getByte(0x03);
CINRequestConts.TYPE_EMOTICON = CinBase64.getByte(0x04);
CINRequestConts.TYPE_GRAFFI = CinBase64.getByte(0x05);
CINRequestConts.TYPE_CARD = CinBase64.getByte(0x06);
CINRequestConts.TYPE_LOCATION = CinBase64.getByte(0x07);
CINRequestConts.TYPE_FREE_SMS = CinBase64.getByte(0x08);
CINRequestConts.TYPE_PP = CinBase64.getByte(0x0D);

CINRequestConts.TYPE_PUBLIC_IMAGETEXT = CinBase64.getByte(0x0C);
CINRequestConts.TYPE_CLIENT_FORWARD_IMAGETEXT = CinBase64.getByte(0x0D);
CINRequestConts.TYPE_CLIENT_FORWARD_PUBLICACCOUNT_CARD = CinBase64.getByte(0x0E);
CINRequestConts.TYPE_RMCSHARE_STORY = CinBase64.getByte(0x1E);
CINRequestConts.TYPE_JIOMONEY = CinBase64.getByte(0x0F);

CINRequestConts.RECORDROUTE = CinBase64.getByte(0x0F);
CINRequestConts.PUSHTOKEN = CinBase64.getByte(0x10);
CINRequestConts.KEY = CinBase64.getByte(0x12);
CINRequestConts.STATUS = CinBase64.getByte(0x13);
CINRequestConts.DEVICETOKEN = CinBase64.getByte(0x14);
CINRequestConts.VERSION = CinBase64.getByte(0x15);
CINRequestConts.INDEX = CinBase64.getByte(0x16);
CINRequestConts.NAME = CinBase64.getByte(0x17);
CINRequestConts.SUBVERSION = CinBase64.getByte(0x18);
CINRequestConts.EMAIL = CinBase64.getByte(0x19);
CINRequestConts.LANGUAGE = CinBase64.getByte(0x1A);
CINRequestConts.CAPABILITY = CinBase64.getByte(0x1B);
CINRequestConts.ENCRYPT = CinBase64.getByte(0x1C);
CINRequestConts.CLEAR_MSG_NUMBER = CinBase64.getByte(0x1C);
CINRequestConts.JIOMONEYMSG = CinBase64.getByte(0x1D);
CINRequestConts.FPID = CinBase64.getByte(0xF9);
CINRequestConts.TPID = CinBase64.getByte(0xFA);
CINRequestConts.SERVERDATA = CinBase64.getByte(0xFB);
CINRequestConts.SERVERPID = CinBase64.getByte(0xFC);
CINRequestConts.SERVERKEY = CinBase64.getByte(0xFD);
CINRequestConts.UNKNOWN = CinBase64.getByte(0xFE);
CINRequestConts.BODY = CinBase64.getByte(0xFF);
CINRequestConts.END = CinBase64.getByte(0x00);
CINRequestConts.DATAMIGRATION = CinBase64.getByte(0x33);
CINRequestConts.JioMoneyTransactionStatus = CinBase64.getByte(0x81);
CINRequestConts.JioMoneyTransactionErrorMessage = CinBase64.getByte(0x82);
//public static final byte JioMoneyTransactionId = CinBase64.getByte(0x87);
CINRequestConts.TIME = CinBase64.getByte(0x83);
CINRequestConts.MPINSTATUS = CinBase64.getByte(0x84);
CINRequestConts.PASSWORDMODIFIEDTIME = CinBase64.getByte(0x85);
CINRequestConts.BALANCE = CinBase64.getByte(0x86);
CINRequestConts.transactionDetails = CinBase64.getByte(0x88);
CINRequestConts.transactionRefId = CinBase64.getByte(0x89);
CINRequestConts.senderMobileNo = CinBase64.getByte(0x8A);
CINRequestConts.receiverMobileNo = CinBase64.getByte(0x8B);
CINRequestConts.transactionType = CinBase64.getByte(0x8C);
CINRequestConts.AMOUNT = CinBase64.getByte(0x8D);
CINRequestConts.FirstName = CinBase64.getByte(0x8E);
CINRequestConts.LastName = CinBase64.getByte(0x8F);
CINRequestConts.apiName = CinBase64.getByte(0x2A);
CINRequestConts.OTP = CinBase64.getByte(0x49);
CINRequestConts.JioMoneyTransactionId = CinBase64.getByte(0x44);
CINRequestConts.JioMoneyTransactionStartDate = CinBase64.getByte(0x41);
CINRequestConts.JioMoneyTransactionEndDate = CinBase64.getByte(0x42);
CINRequestConts.JioMoneyReceiverMobileNumber = CinBase64.getByte(0x48);
CINRequestConts.JioMoneyTransactionType = CinBase64.getByte(0x4A);
CINRequestConts.JioMoneyTransactionAmount = CinBase64.getByte(0x4B);
CINRequestConts.SYNC_BATCH = CinBase64.getByte(0x99);


CINRequestConts.EVENT_SEND_MSG = CinBase64.getByte(0x01);
CINRequestConts.EVENT_DELETE_MSG = CinBase64.getByte(0x08);



CINRequestConts.READ_REPLY_TYPE_DELETE_SESSION = 1; //CinBase64.getByte(0x01);//or decimal 1

// contact sync
CINRequestConts.GET_USER_ID_BODY_PHONE = CinBase64.getByte(0x01);
CINRequestConts.GET_USER_ID_BODY_ID = CinBase64.getByte(0x02);
CINRequestConts.GET_ACTIVE_STATUS_BODY_ID = CinBase64.getByte(0x03);
CINRequestConts.GET_USER_ID_BODY_NAME = CinBase64.getByte(0x02);
CINRequestConts.EVENT_GET_USERID = CinBase64.getByte(0x07);

//delete contact
CINRequestConts.EVENT_DELETE_CONTACT_LIST = CinBase64.getByte(0x12);

// blacklist 
CINRequestConts.EVENT_HANDLE_BLACK_LIST = CinBase64.getByte(0x05);
CINRequestConts.EVENT_GET_BLACK_LIST = CinBase64.getByte(0x06);
CINRequestConts.HANDLE_ADD = CinBase64.getByte(0x01);
CINRequestConts.HANDLE_REMOVE = CinBase64.getByte(0x00);
CINRequestConts.HANDLE_DELETE_ALL = CinBase64.getByte(0x02);
CINRequestConts.HEADER_USER_ID = CinBase64.getByte(0x01);
CINRequestConts.HEADER_NAME = CinBase64.getByte(0x02);
CINRequestConts.HEADER_MOBILE = CinBase64.getByte(0x03);
CINRequestConts.MOBILE = CinBase64.getByte(0x02);

CINRequestConts.EVENT_MESSAGE = CinBase64.getByte(0x01);

CINRequestConts.SESSIONGROUP = CinBase64.getByte(0x01);
CINRequestConts.SESSIONSINGLE = CinBase64.getByte(0x02);
CINRequestConts.SESSIONPUBLIC = CinBase64.getByte(0x03);
CINRequestConts.SESSIONROBOT = CinBase64.getByte(0x04);

CINRequestConts.MESSAGE_READREPLY = CinBase64.getByte(0x01);
CINRequestConts.HAS_PUBLIC_FUNCTION = true;

CINRequestConts.PUSH_AUTH_KEY = CinBase64.getByte(0x01);
CINRequestConts.PUSH_PUBLIC_KEY = CinBase64.getByte(0x02);
CINRequestConts.PUSH_END_POINT_KEY = CinBase64.getByte(0x03);
CINRequestConts.APP_TYPE = CinBase64.getByte(0x04);

CINRequestConts.INFO_HEADER_USERID = CinBase64.getByte(0x01);
CINRequestConts.INFO_HEADER_OFFLINE_COUNT = CinBase64.getByte(0x02);
CINRequestConts.INFO_HEADER_OFFLINE_READ_SEQ = CinBase64.getByte(0x03);
CINRequestConts.INFO_HEADER_USER_INFO_FLAG = CinBase64.getByte(0x0A);

CINRequestConts.EVENT_GET_HISTORY_COUNT = CinBase64.getByte(0x03);
CINRequestConts.EVENT_GET_OFFLINE_MSG = CinBase64.getByte(0x04);
CINRequestConts.EVENT_CLEAR_SESSION = CinBase64.getByte(0x05);
CINRequestConts.EVENT_GET_UN_ARRIVED_SEQUENCE = CinBase64.getByte(0x06);
CINRequestConts.EVENT_DELETE_SINGLE_MESSAGE = CinBase64.getByte(0x08);
CINRequestConts.EVENT_GET_AVSESSION_OFFILINE = CinBase64.getByte(0x0D);
CINRequestConts.EVENT_CLEAR_AVSESSION_OFFILINE = CinBase64.getByte(0x0A);
CINRequestConts.EVENT_ROBOTORPUBLIC_ID = CinBase64.getByte(0x01);
CINRequestConts.EVENT_MESSAGE_VERSION = CinBase64.getByte(0x02);
CINRequestConts.EVENT_ROBOT_OFFLINE_MESSAGE = CinBase64.getByte(0x02);
CINRequestConts.EVENT_PUBLIC_OFFLINE_MESSAGE = CinBase64.getByte(0x02);


CINRequestConts.EVENT_INVITE_BY_EMAIL = CinBase64.getByte(0x03);
CINRequestConts.EVENT_INVITE_BY_SMS = CinBase64.getByte(0x04);
CINRequestConts.EVENT_SET_DND = CinBase64.getByte(0x21);
CINRequestConts.EVENT_SET_SOCIAL_NOTIFY = CinBase64.getByte(0x25);
CINRequestConts.EVENT_SET_LAST_SEEN = CinBase64.getByte(0x26);
CINRequestConts.EVENT_SET_MESSAGE_PREVIEW = CinBase64.getByte(0x27);
CINRequestConts.EVENT_SET_MESSAGE_READREPLY = CinBase64.getByte(0x28);
CINRequestConts.EVENT_GET_FREE_SMS_QUOTA = CinBase64.getByte(0x40);
CINRequestConts.EVENT_CHANGE_LANGUAGE = CinBase64.getByte(0x41);
CINRequestConts.TYPE_RECEIVE_CONTENT = CinBase64.getByte(0x01);
CINRequestConts.TYPE_RECEIVE_FRIEND = CinBase64.getByte(0x02);

// feedback
CINRequestConts.EVENT_FEEDBACK = CinBase64.getByte(0x01);

//Data transmission
CINRequestConts.EVENT_START = CinBase64.getByte(0x21);
CINRequestConts.EVENT_PAUSE = CinBase64.getByte(0x25);
CINRequestConts.EVENT_CONFIRM = CinBase64.getByte(0x23);
CINRequestConts.EVENT_TRANSPORT = CinBase64.getByte(0x22);
CINRequestConts.SESSIONROBOT = CinBase64.getByte(0x04);
CINRequestConts.EVENT_GETLIST = CinBase64.getByte(0x01);
CINRequestConts.EVENT_GETEMOTICONINFO = CinBase64.getByte(0x02);
CINRequestConts.EVENT_ORDER = CinBase64.getByte(0x03);
CINRequestConts.EVENT_GETORDEREDLIST = CinBase64.getByte(0x04);
CINRequestConts.EVENT_CHECKORDEREMOTICON = CinBase64.getByte(0x05);
CINRequestConts.EVENT_GET_RECOMMEND_EMOTICON_LIST = CinBase64.getByte(0x06);
CINRequestConts.EVENT_DATA_CONFIRM = CinBase64.getByte(0x23);

CINRequestConts.PPService = CinBase64.getByte(0x1E);
CINRequestConts.PPMessage = CinBase64.getByte(0x1F);


//Add new resolution details
CINRequestConts.RESOLUTION_DETAILS=CinBase64.getByte(0x1F);

//CIN body check
CINRequestConts.IS_CIN_BODY=255;
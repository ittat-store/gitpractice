function AppMode() { }

// AppType definitions
AppMode.APP_TYPE_JVC = "JVC";
AppMode.APP_TYPE_JC = "JC";
AppMode.APP_TYPE_JCL = "JCL";
AppMode.APP_TYPE_JMS = "JMS";
AppMode.APP_TYPE_JSDK = "JSDK";
AppMode.APP_TYPE_DESKTOP = "DESKTOP";
AppMode.APP_TYPE_MOBILE = "MOBILE";
AppMode.APP_TYPE_TIZEN = "TIZEN";

//App is in JVC Mode
AppMode.TYPE = AppMode.APP_TYPE_JVC;
AppMode.APP_VERSION_JVC = 'v1.3.62';

//AppModes = JVC | JC | JCL | JMS | JSDK | DESKTOP | MOBILE | TIZEN
AppMode.FINAL_VERSION = AppMode.APP_VERSION_JVC;

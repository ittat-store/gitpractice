function GroupMapping() {
    this.groupId = "";
    this.userId = "";
    this.userName = "";
    this.phoneBookName = "";
    this.colorCode = "";
    this.mobileNumber = "";
    this.avatarUrl = "";
}

GroupMapping.prototype = {
    constructor: GroupMapping,

    addToLDB: function (userId, callback) {
        //Arranging Contact Data to be inserted
        var data = {
            groupId: this.groupId,
            userId: this.userId,
            userName: this.userName,
            phoneBookName: this.phoneBookName,
            colorCode: this.colorCode,
            mobileNumber: this.mobileNumber
        }

        var that = this;
        UserDB.getInstance().create(userId, function (success) {
            // console.log("Insert Group : "+UserDB.getInstance().database);
            //Making INSERT group request to Local DB 
            var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_GROUP_MAPPING], "readwrite")
                .objectStore(DatabaseConstants.OBJECT_STORE_GROUP_MAPPING)
                .put(data);

            //Handler for success operation            
            request.onsuccess = function (event) {
                // console.log("GROUP MAPPER CREATED SUCCESSFULLY");
                callback(true)
            };

            //Handler for failure operation                   
            request.onerror = function (event) {
                callback(false)
            }
        });

    },
    updateByDataToLDB: function (userId, data, callback) {
        //Arranging Contact Data to be inserted
        var that = this;
        UserDB.getInstance().create(userId, function (success) {
            // console.log("Insert Group : "+UserDB.getInstance().database);
            //Making INSERT group request to Local DB 
            var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_GROUP_MAPPING], "readwrite")
                .objectStore(DatabaseConstants.OBJECT_STORE_GROUP_MAPPING)
                .put(data);

            //Handler for success operation            
            request.onsuccess = function (event) {
                // console.log("GROUP MAPPER CREATED SUCCESSFULLY");
                callback(true)
            };

            //Handler for failure operation                   
            request.onerror = function (event) {
                callback(false)
            }
        });

    },
    addByGroupDataToLDB: function (userId, group, callback) {
        //Arranging group Data to be inserted
        var that = this;
        UserDB.getInstance().create(userId, function (success) {
            var objectStore = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_GROUP_MAPPING], "readwrite")
                .objectStore(DatabaseConstants.OBJECT_STORE_GROUP_MAPPING);
            putNext(0);

            function putNext(i) {
                if (i < group.users.length) {
                    var groupMember = group.users[i];
                    groupMember.groupId = group.groupId;
                    var request = objectStore.put(groupMember)
                    request.onsuccess = function (event) {
                        putNext(i + 1)
                    };
                } else {   // complete
                    // console.log('populate complete');
                    callback(true);
                }
            }


        });

    },
    addNewMembersToLDB: function (userId, groupData, callback) {
        GroupMapping.getInstance().getByGroupIdFromLDB(userId, groupData.groupId, function (users) {
            // console.log(users);
            var newMembers = [];
            var groupMembers = groupData.users;
            groupMembers.forEach(function (groupMember, userIndex) {
                var isAlreadyThere = false;
                users.forEach(function (user, index) {
                    if (user.userId == groupMember.userId) {
                        // newMembers.push(groupMember);
                        isAlreadyThere = true;
                    }
                });

                if (!isAlreadyThere) {
                    newMembers.push(groupMember);
                };
            });

            var data = {
                groupId: groupData.groupId,
                users: newMembers
            }

            GroupMapping.getInstance().addByGroupDataToLDB(userId, data, function (success) {
                callback(success)
            });


        });
    },
    updateUserNameByUserIdToLDB: function (userId, groupUserId, data, callback) {
        UserDB.getInstance().create(userId, function (success) {
            var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_GROUP_MAPPING, 'readwrite');
            var objectStore = trans
                .objectStore(DatabaseConstants.OBJECT_STORE_GROUP_MAPPING);
            var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_USER_ID);
            // var request = index.get(data.groupId);


            trans.oncomplete = function (evt) {
                callback(true);
            };

            var cursorRequest = index.openCursor(groupUserId);

            cursorRequest.onerror = function (error) {
                // console.log("Error in fetching contacts : "+error);
                callback(false);
            };

            cursorRequest.onsuccess = function (evt) {
                var cursor = evt.target.result;
                if (cursor) {
                    var updateData = cursor.value;
                    if (data.name != undefined && data.name != null) {
                        updateData.userName = data.name;
                    }
                    if (data.setThumbData != undefined && data.setThumbData != null) {
                        updateData.avatarUrl = data.setThumbData;
                    }


                    var res = cursor.update(updateData);
                    res.onsuccess = function (e) {
                        // console.log("update success!!");
                    }
                    res.onerror = function (e) {
                        // console.log("update failed!!");
                        callback(false);
                    }

                    cursor.continue();
                }
            };
        });
    },
    updateMembersInfoToLDB: function (userId, data, callback) {
        UserDB.getInstance().create(userId, function (success) {
            var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_GROUP_MAPPING, 'readwrite');
            var objectStore = trans
                .objectStore(DatabaseConstants.OBJECT_STORE_GROUP_MAPPING);
            var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_USER_ID);


            trans.oncomplete = function (evt) {
                callback(true);
            };

            var cursorRequest = index.openCursor(data.groupUserId);

            cursorRequest.onerror = function (error) {
                // console.log("Error in fetching contacts : "+error);
                callback(false);
            };

            cursorRequest.onsuccess = function (evt) {
                var cursor = evt.target.result;
                if (cursor) {
                    var updateData = cursor.value;

                    if (data.mobileNumber && data.mobileNumber != "") {
                        updateData.mobileNumber = data.mobileNumber;
                    }

                    if (data.avatarUrl && data.avatarUrl != "") {
                        updateData.avatarUrl = data.avatarUrl;
                    }

                    var res = cursor.update(updateData);
                    res.onsuccess = function (e) {
                        // console.log("update success!!");
                    }
                    res.onerror = function (e) {
                        // console.log("update failed!!");
                        callback(false);
                    }

                    cursor.continue();
                }
            };
        });
    },
    getAllFromLDB: function (userId, callback) {
        UserDB.getInstance().create(userId, function (success) {
            var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_GROUP_MAPPING, IDBTransaction.READ_ONLY);
            var store = trans.objectStore(DatabaseConstants.OBJECT_STORE_GROUP_MAPPING);
            var items = [];

            trans.oncomplete = function (evt) {
                callback(items);
            };

            var cursorRequest = store.openCursor();

            cursorRequest.onerror = function (error) {
                // console.log("Error in fetching contacts : "+error);
            };

            cursorRequest.onsuccess = function (evt) {
                var cursor = evt.target.result;
                if (cursor) {
                    items.push(cursor.value);
                    cursor.continue();
                }
            };
        });
    },
    getByGroupIdFromLDB: function (userId, groupId, callback) {
        UserDB.getInstance().create(userId, function (success) {
            var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_GROUP_MAPPING, IDBTransaction.READ_ONLY);
            var objectStore = trans
                .objectStore(DatabaseConstants.OBJECT_STORE_GROUP_MAPPING);
            var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_GROUP_ID);
            var request = index.get(groupId);

            var items = [];
            trans.oncomplete = function (evt) {
                callback(_.sortBy(items, "userName"));
            };

            var cursorRequest = index.openCursor(groupId);

            cursorRequest.onerror = function (error) {
                // console.log("Error in fetching contacts : "+error);
            };

            cursorRequest.onsuccess = function (evt) {
                var cursor = evt.target.result;
                if (cursor) {
                    items.push(cursor.value);
                    cursor.continue();
                }
            };
        });
    },
    getUserInfoByUserIdFromLDB: function (userId, callback) {
        UserDB.getInstance().create(userId, function (success) {
            var trans = UserDB.getInstance().database.transaction(DatabaseConstants.OBJECT_STORE_GROUP_MAPPING, IDBTransaction.READ_ONLY);
            var objectStore = trans
                .objectStore(DatabaseConstants.OBJECT_STORE_GROUP_MAPPING);
            var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_USER_ID);

            var item;
            trans.oncomplete = function (evt) {
                callback(item);
            };

            var cursorRequest = index.openCursor(userId);

            cursorRequest.onerror = function (error) {
                // console.log("Error in fetching contacts : "+error);
            };

            cursorRequest.onsuccess = function (evt) {
                var cursor = evt.target.result;
                if (cursor) {
                    item = cursor.value;
                }
            };
        });
    },
    deleteMemberByGroupIdFromLDB: function (userId, groupId, memberId, callback) {
        UserDB.getInstance().create(userId, function (success) {
            var trans = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_GROUP_MAPPING], 'readwrite');
            var objectStore = trans
                .objectStore(DatabaseConstants.OBJECT_STORE_GROUP_MAPPING);
            var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_GROUP_ID);

            var isSuccess = false;
            trans.oncomplete = function (evt) {
                callback(isSuccess);
            };

            var cursorRequest = index.openCursor(groupId);

            cursorRequest.onerror = function (error) {
                // console.log("Error in fetching contacts : "+error);
                callback(false);
            };

            cursorRequest.onsuccess = function (evt) {
                var cursor = evt.target.result;
                if (cursor) {
                    if (cursor.value.userId == memberId) {
                        var request = cursor.delete();
                        request.onsuccess = function () {
                            // console.log('Deleted Group Member');
                            isSuccess = true;
                        };
                        request.onerror = function (error) {
                            // console.log('Delete Memeber Failed');
                            callback(false);
                        };
                    }

                    cursor.continue();
                }
            };
        });
    },
    deleteByGroupIdFromLDB: function (userId, groupId, callback) {
        UserDB.getInstance().create(userId, function (success) {
            var trans = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_GROUP_MAPPING], 'readwrite');
            var objectStore = trans
                .objectStore(DatabaseConstants.OBJECT_STORE_GROUP_MAPPING);
            var index = objectStore.index(DatabaseConstants.OBJECT_INDEX_GROUP_ID);

            var isSuccess = false;
            trans.oncomplete = function (evt) {
                callback(isSuccess);
            };

            var cursorRequest = index.openCursor(groupId);

            cursorRequest.onerror = function (error) {
                // console.log("Error in fetching contacts : "+error);
                callback(false);
            };

            cursorRequest.onsuccess = function (evt) {
                var cursor = evt.target.result;
                if (cursor) {

                    var request = cursor.delete();
                    request.onsuccess = function () {
                        // console.log('Deleted Group Member');
                        isSuccess = true;
                    };
                    request.onerror = function (error) {
                        // console.log('Delete Memeber Failed');
                        callback(false);
                    };


                    cursor.continue();
                }
            };
        });
    },
    deleteAllFromLDB: function (userId, callback) {
        UserDB.getInstance().create(userId, function (success) {
            //Making DELETE ALL contacts request to Local DB 
            var request = UserDB.getInstance().database.transaction([DatabaseConstants.OBJECT_STORE_GROUP_MAPPING], "readwrite")
                .objectStore(DatabaseConstants.OBJECT_STORE_GROUP_MAPPING)
                .clear();

            //Handler for success operation
            request.onsuccess = function (event) {
                callback(true);
            };

            //Handler for success operation
            request.onerror = function (event) {
                callback(false);
            }
        });
    }

};

GroupMapping.getInstance = function () {
    if (!GroupMapping.instance) {
        GroupMapping.instance = new GroupMapping();
    }
    return GroupMapping.instance;
};

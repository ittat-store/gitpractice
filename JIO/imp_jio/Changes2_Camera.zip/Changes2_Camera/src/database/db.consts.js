function DatabaseConstants () {}

//Database Global Constants
DatabaseConstants.DB_NAME       = "sureshDBDB1234567890";
// DatabaseConstants.COMMON_DB_NAME = "common11.db";
// DatabaseConstants.DB_VERSION     = 1;

//LOCAL STORAGE
DatabaseConstants.USER_CIPHER_DB_VERSION = "USER_CIPHER_DB_VERSION_NUMBER";
DatabaseConstants.USER_DB_VERSION        = "USER_DB_VERSION_NUMBER";
DatabaseConstants.COMMON_DB_VERSION      = "COMMON_DB_VERSION_NUMBER";

//Object Stores
DatabaseConstants.OBJECT_STORE_ACTIVE_USER  = "activeUser";
DatabaseConstants.OBJECT_STORE_CONTACTS     = "contacts";
DatabaseConstants.OBJECT_STORE_SESSION      = "session";
DatabaseConstants.OBJECT_STORE_MESSAGES     = "messages";
DatabaseConstants.OBJECT_STORE_GROUP        = "group";
DatabaseConstants.OBJECT_STORE_GROUP_MAPPING= "group_mapping";
DatabaseConstants.OBJECT_STORE_SETTINGS     = "settings";
DatabaseConstants.OBJECT_STORE_DEVICES      = "devices";
DatabaseConstants.OBJECT_STORE_EMOTICONS    = "emoticons";
DatabaseConstants.OBJECT_STORE_RECENT_EMOTICONS    = "recent_emoticons";	 
DatabaseConstants.OBJECT_STORE_MY_EMOTICONS    = "my_emoticons";
DatabaseConstants.OBJECT_STORE_EMOTICONS_STORE  = "emoticons_store";
DatabaseConstants.OBJECT_STORE_DEVICES      = "devices";
DatabaseConstants.OBJECT_STORE_FILE_DOWNLOAD      = "file_download";

DatabaseConstants.OBJECT_STORE_CHANNELS_LIST        = "channels_list";
DatabaseConstants.OBJECT_STORE_CHANNELS_CONTENT     = "channels_content";
DatabaseConstants.OBJECT_STORE_CHANNELS_CONTENT_PAGE= "channels_contect_page";
DatabaseConstants.OBJECT_STORE_CHANNELS_PROFILE     = "channels_profile";
DatabaseConstants.OBJECT_STORE_BROADCAST_MESSAGE     = "broadcast_message";
DatabaseConstants.OBJECT_STORE_RECENT_CALL_DETAIL     = "recent_call";
DatabaseConstants.OBJECT_STORE_FOCUS_CHANNELS_LIST        = "focus_channels_list";


/*********** Object Stores Indexes *************/
//Active User - Object Indexes
DatabaseConstants.OBJECT_INDEX_USER_ID                  = "userId";
DatabaseConstants.OBJECT_INDEX_MOBILE_NUMBER            = "mobileNumber";
DatabaseConstants.OBJECT_INDEX_PWD                      = "pwd";
DatabaseConstants.OBJECT_INDEX_TOKEN                    = "token";
DatabaseConstants.OBJECT_INDEX_USER_NAME                = "userName";
DatabaseConstants.OBJECT_INDEX_STATUS                   = "status";
DatabaseConstants.OBJECT_INDEX_DOMAIN                   = "domain";
DatabaseConstants.OBJECT_INDEX_CMP_ADDRESS              = "cmpAddress";
DatabaseConstants.OBJECT_INDEX_SERVER_NUMBER            = "serverNumber";
DatabaseConstants.OBJECT_INDEX_NAV_RESPONSE             = "navResponse";
DatabaseConstants.OBJECT_INDEX_SERVER_KEY               = "serverKey";
DatabaseConstants.OBJECT_INDEX_CREDENTIAL               = "credential";
DatabaseConstants.OBJECT_INDEX_DATE_TIME                = "dateTime";
DatabaseConstants.OBJECT_INDEX_TOKEN_EXPIRY             = "tokenExpiry";
DatabaseConstants.OBJECT_INDEX_LANGUAGE                 = "language";
DatabaseConstants.OBJECT_INDEX_DEVICE_MODEL             = "deviceModel";
DatabaseConstants.OBJECT_INDEX_USER_IMAGE               = "userImage";
DatabaseConstants.OBJECT_INDEX_USER_GENDER              = "userGender";
DatabaseConstants.OBJECT_INDEX_USER_MOOD                = "userMood";
DatabaseConstants.OBJECT_INDEX_USER_QR_CODE             = "userQRCode";
DatabaseConstants.OBJECT_INDEX_TERMS_CONDITIONS         = "termsConditions";
DatabaseConstants.OBJECT_INDEX_FAQ                      = "faq";
DatabaseConstants.OBJECT_INDEX_PORTRAIT_ID              = "portraitId";
DatabaseConstants.OBJECT_INDEX_THUMB_DATA               = "thumbData";

//Devices - Object Indexes
DatabaseConstants.OBJECT_INDEX_DEVICE_ID                   = "deviceId";
DatabaseConstants.OBJECT_INDEX_DEVICE_AUTH                 = "deviceAuth";
DatabaseConstants.OBJECT_INDEX_DEVICE_PRIVATE_STR          = "devicePrivateString";
DatabaseConstants.OBJECT_INDEX_DEVICE_END_POINT            = "deviceEndPoint";



//Contacts - Object Indexes
DatabaseConstants.OBJECT_INDEX_CONTACT_ID           = "contactId";
DatabaseConstants.OBJECT_INDEX_MOBILE_NUMBER        = "mobileNumber";
DatabaseConstants.OBJECT_INDEX_PHONE_BOOK_NAME      = "phoneBookName";
DatabaseConstants.OBJECT_INDEX_PHONE_BOOK_PINYIN    = "phoneBookPinyin";
DatabaseConstants.OBJECT_INDEX_USER_ID              = "userId";
DatabaseConstants.OBJECT_INDEX_RCS_NAME             = "rcsName";
DatabaseConstants.OBJECT_INDEX_RCS_PINYIN           = "rcsPinyin";
DatabaseConstants.OBJECT_INDEX_RCS_DATA             = "rcsData";
DatabaseConstants.OBJECT_INDEX_RCS_AVATAR           = "rcsAvatar";
DatabaseConstants.OBJECT_INDEX_PHONE_BOOK_DATA      = "phoneBookData";
DatabaseConstants.OBJECT_INDEX_ACTIVE_STATUS        = "activeStatus";
DatabaseConstants.OBJECT_INDEX_IS_BLACK             = "isBlack";
DatabaseConstants.OBJECT_INDEX_IS_HIDE              = "isHide";
DatabaseConstants.OBJECT_INDEX_CARD_VERSION         = "cardVersion";
DatabaseConstants.OBJECT_INDEX_GENDER               = "gender";
DatabaseConstants.OBJECT_INDEX_MOOD                 = "mood";
DatabaseConstants.OBJECT_INDEX_EXPRESSION           = "expression";
DatabaseConstants.OBJECT_INDEX_COMPANY              = "company";
DatabaseConstants.OBJECT_INDEX_FAVORITE             = "favorite";
DatabaseConstants.OBJECT_INDEX_IS_PHONEBOOK_CONTACT = "isPhoneBookContact";
DatabaseConstants.OBJECT_INDEX_COLOR_CODE           = "colorCode";

//Messages - Object Indexes
DatabaseConstants.OBJECT_INDEX_MSG_ID               = "msgId";
DatabaseConstants.OBJECT_INDEX_MSG_CONTENT          = "msgContent";
DatabaseConstants.OBJECT_INDEX_MSG_DIRECTION        = "msgDirection";
DatabaseConstants.OBJECT_INDEX_MSG_TYPE             = "msgType";
DatabaseConstants.OBJECT_INDEX_MSG_FROM             = "msgFrom";
DatabaseConstants.OBJECT_INDEX_MSG_TO               = "msgTo";
DatabaseConstants.OBJECT_INDEX_MSG_DATE_TIME        = "msgDateTime";
DatabaseConstants.OBJECT_INDEX_MSG_LOCAL_DATE_TIME  = "msgLocalDateTime";
DatabaseConstants.OBJECT_INDEX_MSG_THUMB_STATUS     = "msgThumbStatus";
DatabaseConstants.OBJECT_INDEX_MSG_STATUS           = "msgStatus";
DatabaseConstants.OBJECT_INDEX_MSG_FILE_STATUS      = "msgFileStatus";
DatabaseConstants.OBJECT_INDEX_MSG_READ             = "msgRead";
DatabaseConstants.OBJECT_INDEX_MSG_SEQUENCE         = "msgSequence";
DatabaseConstants.OBJECT_INDEX_MSG_LOCAL_SEQUENCE   = "msgLocalSequence";
DatabaseConstants.OBJECT_INDEX_MSG__DELETE          = "msgDelete";
DatabaseConstants.OBJECT_INDEX_MSG_TOS              = "msgTOS";
DatabaseConstants.OBJECT_INDEX_MSG_MULTIMEDIA       = "msgMultimedia";
DatabaseConstants.OBJECT_INDEX_MSG_LISTEN           = "msgListen";
DatabaseConstants.OBJECT_INDEX_MSG_RECENT           = "msgRecent"
DatabaseConstants.OBJECT_INDEX_MSG_FILE_ID          = "fileId";
DatabaseConstants.OBJECT_INDEX_MSG_THUMB_ID         = "mThumbId";
DatabaseConstants.OBJECT_INDEX_MSG_THUMB_LOCAL_PATH = "thumbLocalPath";
DatabaseConstants.OBJECT_INDEX_MSG_FILE_LOCAL_PATH  = "fileLocalPath";
DatabaseConstants.OBJECT_INDEX_CALL_MODE            = "callMode";
DatabaseConstants.OBJECT_INDEX_MSG_UNREAD_COUNT     = "unreadCount";
DatabaseConstants.OBJECT_INDEX_MSG_ORDER_ID         = "version";
// DatabaseConstants.OBJECT_INDEX_MSG_BADGE_COUNT      = "badgeCount";


//Sessions - Object Indexes
DatabaseConstants.OBJECT_INDEX_SESSION_ID       = "sessionId";
DatabaseConstants.OBJECT_INDEX_PEER_ID          = "peerId";
DatabaseConstants.OBJECT_INDEX_MOBILE_NUMBER    = "mobileNumber";
DatabaseConstants.OBJECT_INDEX_SESSION_TYPE     = "sessionType";
DatabaseConstants.OBJECT_INDEX_NAME             = "name";
DatabaseConstants.OBJECT_INDEX_USER_IDS         = "userIds";
DatabaseConstants.OBJECT_INDEX_IS_TOP           = "isTop";
DatabaseConstants.OBJECT_INDEX_IS_SHOW          = "isShow";
DatabaseConstants.OBJECT_INDEX_IS_DELETE        = "isDelete";
DatabaseConstants.OBJECT_INDEX_MAX_VERSION      = "maxVersion";
DatabaseConstants.OBJECT_INDEX_LAST_MESSAGE     = "lastMessage";
DatabaseConstants.OBJECT_INDEX_DRAFT_MESSAGE    = "draftMessage";
DatabaseConstants.OBJECT_INDEX_SESSION_IMAGE_DATA= "sessionImageData";
DatabaseConstants.OBJECT_INDEX_IS_READ          = "isRead";


//Group - Object Indexes
DatabaseConstants.OBJECT_INDEX_GROUP_ID              = "groupId";
DatabaseConstants.OBJECT_INDEX_GROUP_NAME            = "groupName";
DatabaseConstants.OBJECT_INDEX_GROUP_MAX_COUNT       = "groupMaxCount";
DatabaseConstants.OBJECT_INDEX_USER_IDS              = "userIds";
DatabaseConstants.OBJECT_INDEX_GROUP_VERSION         = "groupVersion";
DatabaseConstants.OBJECT_INDEX_GROUP_CREATOR_ID      = "groupCreatorId";
DatabaseConstants.OBJECT_INDEX_GROUP_MESSAGE_TYPE    = "groupMessageType";
DatabaseConstants.OBJECT_INDEX_GROUP_IS_TOP          = "groupIsTop";
DatabaseConstants.OBJECT_INDEX_GROUP_PORTRAIT_ID     = "groupProtraitId";
DatabaseConstants.OBJECT_INDEX_GROUP_PROTRAIT_SIZE   = "groupPortraitSize";
DatabaseConstants.OBJECT_INDEX_GROUP_THUMB           = "groupThumb";
DatabaseConstants.OBJECT_INDEX_GROUP_IMAGE_DATA      = "groupImageData";

//Settings - Object Indexes
DatabaseConstants.SETTING_NAME                      = "settingName";
DatabaseConstants.SETTING_KEY                       = "settingKey";
DatabaseConstants.SETTING_VALUE                     = "settingValue";
DatabaseConstants.SETTING_DESCRIPTION               = "settingDescription";
DatabaseConstants.SETTING_SEQUENCE                  = "seqId";


//Emoticons - Object Indexes
DatabaseConstants.EMOTICON_ID                      = "emoticonId";
DatabaseConstants.EMOTICON_WIDTH                   = "emoticonWidth";
DatabaseConstants.EMOTICON_HEIGHT                  = "emoticonHeight";
DatabaseConstants.EMOTICON_LOCAL                   = "emoticonLocal";
DatabaseConstants.EMOTICON_STATUS                  = "emoticonStatus";
DatabaseConstants.EMOTICON_PACKAGE_ID              = "emoticonPackageId";
DatabaseConstants.EMOTICON_PACKAGE_TOKEN           = "emoticonPackageToken";
DatabaseConstants.EMOTICON_FILE_SIZE               = "emoticonFileSize";
DatabaseConstants.EMOTICON_ICON_SIZE               = "emoticonIconSize";
DatabaseConstants.EMOTICON_PATH                    = "emoticonPath";
DatabaseConstants.EMOTICON_ICON_PATH               = "emoticonIconPath";
DatabaseConstants.EMOTICON_FILE_ID                 = "emoticonFileId";
DatabaseConstants.EMOTICON_ICON_ID                 = "emoticonIconId";
DatabaseConstants.EMOTICON_RANK                    = "emoticonRank";
  
//My Emoticons - Oject Indexeds	 
DatabaseConstants.EMOTICON_ID                      = "emoticonId";
DatabaseConstants.EMOTICON_SEQUENCE                = "emoticonSequence";
DatabaseConstants.EMOTICON_VERSION                 = "emoticonVersion";
DatabaseConstants.EMOTICON_PROGRESS                = "emoticonProgress";
DatabaseConstants.EMOTICON_STATUS                  = "emoticonStatus";
DatabaseConstants.EMOTICON_PAY_TYPE                = "emoticonPayType";
DatabaseConstants.EMOTICON_IS_NEW                  = "emoticonIsNew";
DatabaseConstants.EMOTICON_PACKAGE_ID              = "emoticonPackageId";
DatabaseConstants.EMOTICON_SIZE                    = "emoticonSize";
DatabaseConstants.EMOTICON_PRICE                   = "emoticonPrice";
DatabaseConstants.EMOTICON_DESC_PROGRESS           = "emoticonDescProgress";
DatabaseConstants.EMOTICON_HAS_UPLOAD              = "emoticonHasUpload";
DatabaseConstants.EMOTICON_PANEL_NORTH_PATH        = "emoticonPanelNorthPath";
DatabaseConstants.EMOTICON_PANEL_SELECT_PATH       = "emoticonPanelSelectPath";
DatabaseConstants.EMOTICON_PANEL_THUMB_PATH        = "emoticonPanelThumbPath";
DatabaseConstants.EMOTICON_DESC_IMAGE_PATH         = "emoticonDescImagePath";
DatabaseConstants.EMOTICON_LOCAL_SEQUENCE          = "emoticonLocalSequence";
DatabaseConstants.EMOTICON_IS_ORDERED              = "emoticonIsOrdered";
DatabaseConstants.EMOTICON_PATH                    = "emoticonPath";
DatabaseConstants.EMOTICON_DOWNLOAD_INDEX          = "emoticonDownloadIndex";
DatabaseConstants.EMOTICON_BLOCK_SIZE              = "emoticonBlockSize";
DatabaseConstants.EMOTICON_NAME                    = "emoticonName";
DatabaseConstants.EMOTICON_TOKEN                   = "emoticonToken";
DatabaseConstants.EMOTICON_DESCRIPTION             = "emoticonDescription";
DatabaseConstants.EMOTICON_DEVELOPERS              = "emoticonDevelopers";
DatabaseConstants.EMOTICON_THUMB_PATH              = "emoticonThumbPath";
DatabaseConstants.EMOTICON_THUMB_ID                = "emoticonThumbId";
DatabaseConstants.EMOTICON_THUMB_SIZE              = "emoticonThumbSize";
DatabaseConstants.EMOTICON_DESC_IMAGE_ID           = "emoticonDescImageId";
DatabaseConstants.EMOTICON_DESC_IMAGE_SIZE         = "emoticonDescImageSize";



//ChannelList - Object Index
DatabaseConstants.CHANNEL_INDEX                         = "channelIndex";
DatabaseConstants.CHANNEL_ID                            = "channelId";
DatabaseConstants.SERVER_CHANNEL_ID                     = "serverChannelId";
DatabaseConstants.CHANNEL_PROFILE_VERSION               = "channelProfileVersion";
DatabaseConstants.CHANNEL_CONTENT_VERSION               = "channelContentVersion";
DatabaseConstants.CHANNEL_GLOBAL_ID                     = "channelGlobalId";
DatabaseConstants.SERVER_CHANNEL_STATUS                 = "serverChannelStatus";
DatabaseConstants.SERVER_CHANNEL_CHECK                  = "serverChannelCheck";
DatabaseConstants.SERVER_CHANNEL_NEED_PLAY_INTRO_VIDEO  = "serverChannelNeedPlayIntroVideo";
DatabaseConstants.CHANNEL_GET_OK_RESPONSE               = "channelGetOkResponse";
DatabaseConstants.CHANNEL_UPDATE_LOGO_URL               = "channelUpdateLogoURL";

DatabaseConstants.CHANNEL_DESCRIPTION                   = "channelDescription";
DatabaseConstants.CHANNEL_FOLLOW_TYPE                   = "channelFollowType";
DatabaseConstants.CHANNEL_NAME                          = "channelName";
DatabaseConstants.CHANNEL_SERIAL_NUMBER                 = "channelSerialNumber";
DatabaseConstants.CHANNEL_CARD_VERSION                  = "channelCardVersion";
DatabaseConstants.CHANNEL_IS_RECEIVE_MSG                = "channelIsReceivingMessage";
DatabaseConstants.PIN_TO_CHAT                           = "PinToChat";
DatabaseConstants.CHANNEL_PORTRAIT_ID                   = "channelPortraitId";
DatabaseConstants.CHANNEL_PUBLIC_ID                     = "channelPublicId";
DatabaseConstants.CHANNEL_ATTENTIVE                     = "channelAttentive";
DatabaseConstants.CHANNEL_OFFICIAL                      = "channelOfficial";
DatabaseConstants.CHANNEL_IMG_PATH                      = "channelImagePath";
DatabaseConstants.CHANNEL_SUBMENU_JSON                  = "channelSubmenuJSON";
DatabaseConstants.CHANNEL_ISFOLLOWING                   = "channelIsFollowing"

//Channel Contents - Object Index
DatabaseConstants.CHANNEL_CONTENT_ID                    = "channelContentId";
DatabaseConstants.CHANNEL_CONTENT_VERSION               = "channelContentVersion";
DatabaseConstants.CHANNEL_CONTENT_COLUMN_INDEX          = "channelContentColumnIndex";
DatabaseConstants.CHANNEL_CONTENT_SUMMARY_INFO          = "channelContentSummaryInfo";
DatabaseConstants.CHANNEL_CONTENT_COLUMN_TITLE          = "channelContentColumnTitle";
DatabaseConstants.CHANNEL_UNIQUE_ID                     = "channelUniqueContentId"

//Channel Contents Page Info- Object Index
DatabaseConstants.CHANNEL_PAGE_ID                      = "channelPageId";
DatabaseConstants.CHANNEL_PAGE_LOC_INDEX               = "channelPageLocalIndex";
DatabaseConstants.CHANNEL_CONTENT_INFO_ID              = "channelContentInfoId";
DatabaseConstants.CHANNEL_CONTENT_COLUMN_INDEX         = "channelContentColumnIndex";
DatabaseConstants.CHANNEL_CONTENT_TYPE                 = "channelContentType";
DatabaseConstants.CHANNEL_VIDEO_ID                     = "channelVideoId";
DatabaseConstants.CHANNEL_RESOURCE_URI                 = "channelResourceURI";
DatabaseConstants.CHANNEL_MEDIA_HTML                   = "channelMediaHTML";
DatabaseConstants.CHANNEL_MEDIA_VIDEO                  = "channelMediaVideo";
DatabaseConstants.CHANNEL_MEDIA_STREAM                 = "channelMediaStream";



//Channel Profile Info- Object Index
DatabaseConstants.CHANNEL_PROFILE_VERSION       = "channelProfileVersion";
DatabaseConstants.CHANNEL_NAME                  = "channelName";
DatabaseConstants.CHANNEL_SHARE_FLAG            = "channelShareFlag";
DatabaseConstants.CHANNEL_INTRO_VIDEO_ID        = "channelIntroVideoId";
DatabaseConstants.CHANNEL_SHARE_IMAGE_FLAG      = "channelShareImageFlag";
DatabaseConstants.CHANNEL_SHARE_ICON_FLAG       = "channelShareIconFlag";
DatabaseConstants.CHANNEL_TRANSITION_VIDEO_ID   = "channelTransitionVideoId";
DatabaseConstants.CHANNEL_END_VIDEO_ID          = "channelEndVideoId";
DatabaseConstants.CHANNEL_RED_CODE              = "channelRedCode";
DatabaseConstants.CHANNEL_GREEN_CODE            = "channelGreenCode";
DatabaseConstants.CHANNEL_BLUE_CODE             = "channelBlueCode";
DatabaseConstants.CHANNEL_CHANNEL_LOGO_URL      = "channelLogoURL";
DatabaseConstants.CHANNEL_CONTENT_SUMMARY_INFO  = "channelContentSummaryInfo";

//recent call Info- Object Index
DatabaseConstants.RECENT_CALL_LOG_ID            = "callLogId";
DatabaseConstants.RECENT_CALL_ID                = "callerId";
DatabaseConstants.RECENT_CALL_NAME              = "userName";
DatabaseConstants.RECENT_CALL_IMAGE             = "userImage";
DatabaseConstants.RECENT_CALL_TIME              = "callTime";
DatabaseConstants.RECENT_CALL_DATE_TIME         = "dateTime";
DatabaseConstants.RECENT_CALL_TYPE              = "callType";
DatabaseConstants.RECENT_CALL_COLOR_CODE        = "colorCode";
DatabaseConstants.RECENT_CALL_PEER_NUMBER       = "peerNumber";



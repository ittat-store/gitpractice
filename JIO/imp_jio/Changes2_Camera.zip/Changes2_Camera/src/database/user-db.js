function UserDB () {}

UserDB.prototype = {
	constructor: UserDB,
    instance:null,
    database:null,
    create : function(userId, callback) {
        var newDatabaseName = DatabaseUtils.getInstance().getUserDatabseNameForUserId(userId);
        // console.log("New DataBaseName : " + newDatabaseName);
        // if (UserDB.instance.database == null || UserDB.instance.dbName != newDatabaseName){
        if (UserDB.instance.database == null){

            // debugger;

            // mushtaq added this check. Since DB created with null user id
            if (!userId) {
                return;
            }

            var gotDBInstance = false;
            var databaseName = DatabaseUtils.getInstance().getUserDatabseNameForUserId(userId);
            var dbVersion = DatabaseUtils.getInstance().getUserDBVersionNumber();
            UserDB.instance.dbName = databaseName;
            // console.log("Old DataBaseName : " + databaseName);

            //  dbVersion = 2;//Testing
            Database.getInstance().createNewDatabase(databaseName, dbVersion, function(db, req, upgradedbcalled){
                UserDB.instance.database = db;

                // console.log("DB Request : " + db);
                
                //Handler for version updates  
                if (upgradedbcalled) {
                    gotDBInstance = true; 
                    UserDB.instance.createTables(callback); 
                }else{
                    if(!gotDBInstance){
                        gotDBInstance = true; 
                        if (UserDB.instance.database == null){
                            UserDB.instance.sendCallBack(callback, true, 0);
                        }
                        else{
                            UserDB.instance.sendCallBack(callback, false, 0);
                        }
                    }
                } 
            });
        }else{
             UserDB.instance.sendCallBack(callback, true, 0);
        }    
    },
    

    createTables : function(callback){
        if (!UserDB.instance.database.objectStoreNames.contains(DatabaseConstants.OBJECT_STORE_CONTACTS)){
             UserDB.instance.createObjectStoreForContacts();
        };
        if (!UserDB.instance.database.objectStoreNames.contains(DatabaseConstants.OBJECT_STORE_SESSION)){
             UserDB.instance.createObjectStoreForSession();
        };
        if (!UserDB.instance.database.objectStoreNames.contains(DatabaseConstants.OBJECT_STORE_GROUP)){
             UserDB.instance.createObjectStoreForGroups();
        }; 
        if (!UserDB.instance.database.objectStoreNames.contains(DatabaseConstants.OBJECT_STORE_GROUP_MAPPING)){
             UserDB.instance.createObjectStoreForGroupMapping();
        };   
        if (!UserDB.instance.database.objectStoreNames.contains(DatabaseConstants.OBJECT_STORE_SETTINGS)){
             UserDB.instance.createObjectStoreForSettings();
        }; 
        if (!UserDB.instance.database.objectStoreNames.contains(DatabaseConstants.OBJECT_STORE_EMOTICONS_STORE)){
             UserDB.instance.createObjectStoreForEmoticonStore();
        };
        if (!UserDB.instance.database.objectStoreNames.contains(DatabaseConstants.OBJECT_STORE_EMOTICONS)){
             UserDB.instance.createObjectStoreForEmoticons();
        };
        //-------testing recent emoticon db-----
        if (!UserDB.instance.database.objectStoreNames.contains(DatabaseConstants.OBJECT_STORE_RECENT_EMOTICONS)){
            UserDB.instance.createObjectStoreForRecentEmoticons();
        };
        //-------testing recent emoticon db end-----
        if (!UserDB.instance.database.objectStoreNames.contains(DatabaseConstants.OBJECT_STORE_MY_EMOTICONS)){
             UserDB.instance.createObjectStoreForMyEmoticons();
        };
        if (!UserDB.instance.database.objectStoreNames.contains(DatabaseConstants.OBJECT_STORE_CHANNELS_LIST)){
             UserDB.instance.createObjectStoreForChannelsList();
        };
        if (!UserDB.instance.database.objectStoreNames.contains(DatabaseConstants.OBJECT_STORE_FOCUS_CHANNELS_LIST)){
             UserDB.instance.createObjectStoreForFocusChannelsList();
        };
        if (!UserDB.instance.database.objectStoreNames.contains(DatabaseConstants.OBJECT_STORE_CHANNELS_CONTENT)){
             UserDB.instance.createObjectStoreForChannelContents();
        }; 
        if (!UserDB.instance.database.objectStoreNames.contains(DatabaseConstants.OBJECT_STORE_CHANNELS_CONTENT_PAGE)){
             UserDB.instance.createObjectStoreForChannelContentsPage();
        }; 
        if (!UserDB.instance.database.objectStoreNames.contains(DatabaseConstants.OBJECT_STORE_CHANNELS_PROFILE)){
             UserDB.instance.createObjectStoreForChannelsProfile();
        };

        if (!UserDB.instance.database.objectStoreNames.contains(DatabaseConstants.OBJECT_STORE_BROADCAST_MESSAGE)){
             UserDB.instance.createObjectStoreForBroadcastMessage();
        };

        //siva added
        if (!UserDB.instance.database.objectStoreNames.contains(DatabaseConstants.OBJECT_STORE_RECENT_CALL_DETAIL)){
             UserDB.instance.createObjectStoreForRecentCall();
        };

        //Kaal added
        if (!UserDB.instance.database.objectStoreNames.contains(DatabaseConstants.OBJECT_STORE_FILE_DOWNLOAD)){
             UserDB.instance.createObjectStoreForFileDownload();
        };

        UserDB.instance.sendCallBack(callback, true, 1000); 
    },
    createObjectStoreForContacts : function() {
        var objectStore = UserDB.instance.database.createObjectStore(
                    DatabaseConstants.OBJECT_STORE_CONTACTS, { keyPath: DatabaseConstants.OBJECT_INDEX_MOBILE_NUMBER, autoIncrement: true });
   
        //Add Column/Indexes to the contacts store
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_CONTACT_ID, DatabaseConstants.OBJECT_INDEX_CONTACT_ID, { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MOBILE_NUMBER, DatabaseConstants.OBJECT_INDEX_MOBILE_NUMBER, { unique: true });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_PHONE_BOOK_NAME, DatabaseConstants.OBJECT_INDEX_PHONE_BOOK_NAME, { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_PHONE_BOOK_PINYIN, DatabaseConstants.OBJECT_INDEX_PHONE_BOOK_PINYIN, { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_USER_ID, DatabaseConstants.OBJECT_INDEX_USER_ID, { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_RCS_NAME, DatabaseConstants.OBJECT_INDEX_RCS_NAME, { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_RCS_PINYIN , DatabaseConstants.OBJECT_INDEX_RCS_PINYIN , { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_RCS_DATA , DatabaseConstants.OBJECT_INDEX_RCS_DATA , { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_RCS_AVATAR  , DatabaseConstants.OBJECT_INDEX_RCS_AVATAR  , { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_PHONE_BOOK_DATA , DatabaseConstants.OBJECT_INDEX_PHONE_BOOK_DATA , { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_ACTIVE_STATUS , DatabaseConstants.OBJECT_INDEX_ACTIVE_STATUS , { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_IS_BLACK , DatabaseConstants.OBJECT_INDEX_IS_BLACK , { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_IS_HIDE , DatabaseConstants.OBJECT_INDEX_IS_HIDE , { unique: false }); 
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_CARD_VERSION , DatabaseConstants.OBJECT_INDEX_CARD_VERSION , { unique: false });  
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_GENDER , DatabaseConstants.OBJECT_INDEX_GENDER , { unique: false });  
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MOOD , DatabaseConstants.OBJECT_INDEX_MOOD , { unique: false });  
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_COMPANY , DatabaseConstants.OBJECT_INDEX_COMPANY , { unique: false });  
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_FAVORITE , DatabaseConstants.OBJECT_INDEX_FAVORITE , { unique: false });  
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_EXPRESSION , DatabaseConstants.OBJECT_INDEX_EXPRESSION , { unique: false });  
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_IS_PHONEBOOK_CONTACT , DatabaseConstants.OBJECT_INDEX_IS_PHONEBOOK_CONTACT , { unique: false });  
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_COLOR_CODE , DatabaseConstants.OBJECT_INDEX_COLOR_CODE , { unique: false });  
               
     },
     createObjectStoreForSession : function(){
        var objectStore = UserDB.instance.database.createObjectStore(
                                    DatabaseConstants.OBJECT_STORE_SESSION, { keyPath: DatabaseConstants.OBJECT_INDEX_SESSION_ID, autoIncrement: true });

       //Add Column/Indexes to the sessions store
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_SESSION_ID, DatabaseConstants.OBJECT_INDEX_SESSION_ID, { unique: true });

        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_PEER_ID, DatabaseConstants.OBJECT_INDEX_PEER_ID, { unique: false });
        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MOBILE_NUMBER, DatabaseConstants.OBJECT_INDEX_MOBILE_NUMBER, { unique: false });
        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_SESSION_TYPE, DatabaseConstants.OBJECT_INDEX_SESSION_TYPE, { unique: false });
        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_NAME, DatabaseConstants.OBJECT_INDEX_NAME, { unique: false });
        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_USER_IDS, DatabaseConstants.OBJECT_INDEX_USER_IDS, { unique: false });
        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_IS_TOP , DatabaseConstants.OBJECT_INDEX_IS_TOP , { unique: false });
        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_IS_SHOW , DatabaseConstants.OBJECT_INDEX_IS_SHOW , { unique: false });
        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_IS_DELETE  , DatabaseConstants.OBJECT_INDEX_IS_DELETE  , { unique: false });
        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MAX_VERSION , DatabaseConstants.OBJECT_INDEX_MAX_VERSION , { unique: false });
        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_LAST_MESSAGE , DatabaseConstants.OBJECT_INDEX_LAST_MESSAGE , { unique: false });
        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_DRAFT_MESSAGE , DatabaseConstants.OBJECT_INDEX_DRAFT_MESSAGE , { unique: false });
        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MSG_DATE_TIME , DatabaseConstants.OBJECT_INDEX_MSG_DATE_TIME , { unique: false });
        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_IS_READ , DatabaseConstants.OBJECT_INDEX_IS_READ , { unique: false });
        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MSG_TYPE , DatabaseConstants.OBJECT_INDEX_MSG_TYPE , { unique: false });

           
    },
    createObjectStoreForGroups : function(){
        var objectStore = UserDB.instance.database.createObjectStore(
                                    DatabaseConstants.OBJECT_STORE_GROUP, { keyPath: DatabaseConstants.OBJECT_INDEX_GROUP_ID, autoIncrement: true });
       
       //Add Column/Indexes to the contacts store
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_GROUP_ID, DatabaseConstants.OBJECT_INDEX_GROUP_ID, { unique: true });

        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_GROUP_NAME, DatabaseConstants.OBJECT_INDEX_GROUP_NAME, { unique: false });
        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_GROUP_MAX_COUNT, DatabaseConstants.OBJECT_INDEX_GROUP_MAX_COUNT, { unique: false });
        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_GROUP_VERSION, DatabaseConstants.OBJECT_INDEX_GROUP_VERSION, { unique: false });
        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_GROUP_CREATOR_ID, DatabaseConstants.OBJECT_INDEX_GROUP_CREATOR_ID, { unique: false });
        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_GROUP_MESSAGE_TYPE, DatabaseConstants.OBJECT_INDEX_GROUP_MESSAGE_TYPE, { unique: false });
        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_GROUP_IS_TOP , DatabaseConstants.OBJECT_INDEX_GROUP_IS_TOP , { unique: false });
        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_GROUP_PORTRAIT_ID , DatabaseConstants.OBJECT_INDEX_GROUP_PORTRAIT_ID , { unique: false });
        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_GROUP_PROTRAIT_SIZE  , DatabaseConstants.OBJECT_INDEX_GROUP_PROTRAIT_SIZE  , { unique: false });
        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_GROUP_THUMB  , DatabaseConstants.OBJECT_INDEX_GROUP_THUMB  , { unique: false });
        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_USER_IDS  , DatabaseConstants.OBJECT_INDEX_USER_IDS  , { unique: false });
        
        
    },
    createObjectStoreForGroupMapping : function(){
        var objectStore = UserDB.instance.database.createObjectStore(
                                    DatabaseConstants.OBJECT_STORE_GROUP_MAPPING, { keyPath: "mappingId", autoIncrement: true });

       //Add Column/Indexes to the contacts store
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_GROUP_ID, DatabaseConstants.OBJECT_INDEX_GROUP_ID, { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_USER_ID, DatabaseConstants.OBJECT_INDEX_USER_ID, { unique: false });

        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_USER_NAME, DatabaseConstants.OBJECT_INDEX_USER_NAME, { unique: false });        
        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_PHONE_BOOK_NAME, DatabaseConstants.OBJECT_INDEX_PHONE_BOOK_NAME, { unique: false });        
        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_COLOR_CODE, DatabaseConstants.OBJECT_INDEX_COLOR_CODE, { unique: false });        
        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MOBILE_NUMBER, DatabaseConstants.OBJECT_INDEX_MOBILE_NUMBER, { unique: false });        
        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_THUMB_DATA, DatabaseConstants.OBJECT_INDEX_THUMB_DATA, { unique: false });        

    },
    createObjectStoreForSettings : function(){
        var objectStore = UserDB.instance.database.createObjectStore(
                                    DatabaseConstants.OBJECT_STORE_SETTINGS, { keyPath: DatabaseConstants.SETTING_KEY, autoIncrement: true });
       
       //Add Column/Indexes to the contacts store
        objectStore.createIndex(DatabaseConstants.SETTING_KEY, DatabaseConstants.SETTING_KEY, { unique: true });
        objectStore.createIndex(DatabaseConstants.SETTING_VALUE, DatabaseConstants.SETTING_VALUE, { unique: false });        
        objectStore.createIndex(DatabaseConstants.SETTING_NAME, DatabaseConstants.SETTING_NAME, { unique: false });        
        objectStore.createIndex(DatabaseConstants.SETTING_DESCRIPTION, DatabaseConstants.SETTING_DESCRIPTION, { unique: false });        

        
    },
    createObjectStoreForEmoticons : function(){
        var objectStore = UserDB.instance.database.createObjectStore(
                                    DatabaseConstants.OBJECT_STORE_EMOTICONS, { keyPath: DatabaseConstants.EMOTICON_FILE_ID, autoIncrement: true });
       
       //Add Column/Indexes to the contacts store
        objectStore.createIndex(DatabaseConstants.EMOTICON_ID, DatabaseConstants.EMOTICON_ID, { unique: false });
        objectStore.createIndex(DatabaseConstants.EMOTICON_WIDTH, DatabaseConstants.EMOTICON_WIDTH, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_HEIGHT, DatabaseConstants.EMOTICON_HEIGHT, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_LOCAL, DatabaseConstants.EMOTICON_LOCAL, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_STATUS, DatabaseConstants.EMOTICON_STATUS, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_PACKAGE_ID, DatabaseConstants.EMOTICON_PACKAGE_ID, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_PACKAGE_TOKEN, DatabaseConstants.EMOTICON_PACKAGE_TOKEN, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_FILE_SIZE, DatabaseConstants.EMOTICON_FILE_SIZE, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_ICON_SIZE, DatabaseConstants.EMOTICON_ICON_SIZE, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_PATH, DatabaseConstants.EMOTICON_PATH, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_ICON_PATH, DatabaseConstants.EMOTICON_ICON_PATH, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_FILE_ID, DatabaseConstants.EMOTICON_FILE_ID, { unique: true });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_ICON_ID, DatabaseConstants.EMOTICON_ICON_ID, { unique: false });        

    },
    //--------------testing recent emoticon db---------
    createObjectStoreForRecentEmoticons : function(){
        var objectStore = UserDB.instance.database.createObjectStore(
                                    DatabaseConstants.OBJECT_STORE_RECENT_EMOTICONS, { keyPath: DatabaseConstants.EMOTICON_FILE_ID, autoIncrement: true });
       
       //Add Column/Indexes to the recent emoticon
        objectStore.createIndex(DatabaseConstants.EMOTICON_ID, DatabaseConstants.EMOTICON_ID, { unique: false });
        objectStore.createIndex(DatabaseConstants.EMOTICON_WIDTH, DatabaseConstants.EMOTICON_WIDTH, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_HEIGHT, DatabaseConstants.EMOTICON_HEIGHT, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_LOCAL, DatabaseConstants.EMOTICON_LOCAL, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_STATUS, DatabaseConstants.EMOTICON_STATUS, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_PACKAGE_ID, DatabaseConstants.EMOTICON_PACKAGE_ID, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_PACKAGE_TOKEN, DatabaseConstants.EMOTICON_PACKAGE_TOKEN, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_FILE_SIZE, DatabaseConstants.EMOTICON_FILE_SIZE, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_ICON_SIZE, DatabaseConstants.EMOTICON_ICON_SIZE, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_PATH, DatabaseConstants.EMOTICON_PATH, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_ICON_PATH, DatabaseConstants.EMOTICON_ICON_PATH, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_FILE_ID, DatabaseConstants.EMOTICON_FILE_ID, { unique: true });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_ICON_ID, DatabaseConstants.EMOTICON_ICON_ID, { unique: false });
        objectStore.createIndex(DatabaseConstants.EMOTICON_RANK, DatabaseConstants.EMOTICON_RANK, { unique: false });        
                
    },
    //--------------testing recent emoticon db end---------
    
    createObjectStoreForMyEmoticons : function(){
        var objectStore = UserDB.instance.database.createObjectStore(
                                    DatabaseConstants.OBJECT_STORE_MY_EMOTICONS, { keyPath: DatabaseConstants.EMOTICON_ID, autoIncrement: true });
       
       //Add Column/Indexes to the contacts store
        objectStore.createIndex(DatabaseConstants.EMOTICON_ID, DatabaseConstants.EMOTICON_ID, { unique: true });
        objectStore.createIndex(DatabaseConstants.EMOTICON_SEQUENCE, DatabaseConstants.EMOTICON_SEQUENCE, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_VERSION, DatabaseConstants.EMOTICON_VERSION, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_PROGRESS, DatabaseConstants.EMOTICON_PROGRESS, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_STATUS, DatabaseConstants.EMOTICON_STATUS, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_PAY_TYPE, DatabaseConstants.EMOTICON_PAY_TYPE, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_IS_NEW, DatabaseConstants.EMOTICON_IS_NEW, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_PACKAGE_ID, DatabaseConstants.EMOTICON_PACKAGE_ID, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_SIZE, DatabaseConstants.EMOTICON_SIZE, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_PRICE, DatabaseConstants.EMOTICON_PRICE, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_DESC_PROGRESS, DatabaseConstants.EMOTICON_DESC_PROGRESS, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_HAS_UPLOAD, DatabaseConstants.EMOTICON_HAS_UPLOAD, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_PANEL_NORTH_PATH, DatabaseConstants.EMOTICON_PANEL_NORTH_PATH, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_PANEL_SELECT_PATH, DatabaseConstants.EMOTICON_PANEL_SELECT_PATH, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_PANEL_THUMB_PATH, DatabaseConstants.EMOTICON_PANEL_THUMB_PATH, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_DESC_IMAGE_PATH, DatabaseConstants.EMOTICON_DESC_IMAGE_PATH, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_LOCAL_SEQUENCE, DatabaseConstants.EMOTICON_LOCAL_SEQUENCE, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_IS_ORDERED, DatabaseConstants.EMOTICON_IS_ORDERED, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_PATH, DatabaseConstants.EMOTICON_PATH, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_DOWNLOAD_INDEX, DatabaseConstants.EMOTICON_DOWNLOAD_INDEX, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_BLOCK_SIZE, DatabaseConstants.EMOTICON_BLOCK_SIZE, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_NAME, DatabaseConstants.EMOTICON_NAME, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_TOKEN, DatabaseConstants.EMOTICON_TOKEN, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_DESCRIPTION, DatabaseConstants.EMOTICON_DESCRIPTION, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_DEVELOPERS, DatabaseConstants.EMOTICON_DEVELOPERS, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_THUMB_PATH, DatabaseConstants.EMOTICON_THUMB_PATH, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_THUMB_ID, DatabaseConstants.EMOTICON_THUMB_ID, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_THUMB_SIZE, DatabaseConstants.EMOTICON_THUMB_SIZE, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_DESC_IMAGE_ID, DatabaseConstants.EMOTICON_DESC_IMAGE_ID, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_DESC_IMAGE_SIZE, DatabaseConstants.EMOTICON_DESC_IMAGE_SIZE, { unique: false });        

    },
    createObjectStoreForEmoticonStore : function(){
        var objectStore = UserDB.instance.database.createObjectStore(
                                    DatabaseConstants.OBJECT_STORE_EMOTICONS_STORE, { keyPath: DatabaseConstants.EMOTICON_SEQUENCE, autoIncrement: true });
       
       //Add Column/Indexes to the contacts store
        objectStore.createIndex(DatabaseConstants.EMOTICON_ID, DatabaseConstants.EMOTICON_ID, { unique: true });
        objectStore.createIndex(DatabaseConstants.EMOTICON_SEQUENCE, DatabaseConstants.EMOTICON_SEQUENCE, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_VERSION, DatabaseConstants.EMOTICON_VERSION, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_PROGRESS, DatabaseConstants.EMOTICON_PROGRESS, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_STATUS, DatabaseConstants.EMOTICON_STATUS, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_PAY_TYPE, DatabaseConstants.EMOTICON_PAY_TYPE, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_IS_NEW, DatabaseConstants.EMOTICON_IS_NEW, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_PACKAGE_ID, DatabaseConstants.EMOTICON_PACKAGE_ID, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_SIZE, DatabaseConstants.EMOTICON_SIZE, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_PRICE, DatabaseConstants.EMOTICON_PRICE, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_DESC_PROGRESS, DatabaseConstants.EMOTICON_DESC_PROGRESS, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_HAS_UPLOAD, DatabaseConstants.EMOTICON_HAS_UPLOAD, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_PANEL_NORTH_PATH, DatabaseConstants.EMOTICON_PANEL_NORTH_PATH, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_PANEL_SELECT_PATH, DatabaseConstants.EMOTICON_PANEL_SELECT_PATH, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_PANEL_THUMB_PATH, DatabaseConstants.EMOTICON_PANEL_THUMB_PATH, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_DESC_IMAGE_PATH, DatabaseConstants.EMOTICON_DESC_IMAGE_PATH, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_LOCAL_SEQUENCE, DatabaseConstants.EMOTICON_LOCAL_SEQUENCE, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_IS_ORDERED, DatabaseConstants.EMOTICON_IS_ORDERED, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_PATH, DatabaseConstants.EMOTICON_PATH, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_DOWNLOAD_INDEX, DatabaseConstants.EMOTICON_DOWNLOAD_INDEX, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_BLOCK_SIZE, DatabaseConstants.EMOTICON_BLOCK_SIZE, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_NAME, DatabaseConstants.EMOTICON_NAME, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_TOKEN, DatabaseConstants.EMOTICON_TOKEN, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_DESCRIPTION, DatabaseConstants.EMOTICON_DESCRIPTION, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_DEVELOPERS, DatabaseConstants.EMOTICON_DEVELOPERS, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_THUMB_PATH, DatabaseConstants.EMOTICON_THUMB_PATH, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_THUMB_ID, DatabaseConstants.EMOTICON_THUMB_ID, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_THUMB_SIZE, DatabaseConstants.EMOTICON_THUMB_SIZE, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_DESC_IMAGE_ID, DatabaseConstants.EMOTICON_DESC_IMAGE_ID, { unique: false });        
        objectStore.createIndex(DatabaseConstants.EMOTICON_DESC_IMAGE_SIZE, DatabaseConstants.EMOTICON_DESC_IMAGE_SIZE, { unique: false });        

    },
    createObjectStoreForChannelsList : function(){
        var objectStore = UserDB.instance.database.createObjectStore(
                                    DatabaseConstants.OBJECT_STORE_CHANNELS_LIST, { keyPath: DatabaseConstants.CHANNEL_INDEX, autoIncrement: true });
       
       //Add Column/Indexes to the contacts store
        objectStore.createIndex(DatabaseConstants.CHANNEL_INDEX, DatabaseConstants.CHANNEL_INDEX, { autoIncrement: true });
        objectStore.createIndex(DatabaseConstants.CHANNEL_ID, DatabaseConstants.CHANNEL_ID, { unique: true });
        objectStore.createIndex(DatabaseConstants.SERVER_CHANNEL_ID, DatabaseConstants.SERVER_CHANNEL_ID, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_PROFILE_VERSION, DatabaseConstants.CHANNEL_PROFILE_VERSION, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_CONTENT_VERSION, DatabaseConstants.CHANNEL_CONTENT_VERSION, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_GLOBAL_ID, DatabaseConstants.CHANNEL_GLOBAL_ID, { unique: false });        
        objectStore.createIndex(DatabaseConstants.SERVER_CHANNEL_STATUS, DatabaseConstants.SERVER_CHANNEL_STATUS, { unique: false });        
        objectStore.createIndex(DatabaseConstants.SERVER_CHANNEL_CHECK, DatabaseConstants.SERVER_CHANNEL_CHECK, { unique: false });        
        objectStore.createIndex(DatabaseConstants.SERVER_CHANNEL_NEED_PLAY_INTRO_VIDEO, DatabaseConstants.SERVER_CHANNEL_NEED_PLAY_INTRO_VIDEO, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_GET_OK_RESPONSE, DatabaseConstants.CHANNEL_GET_OK_RESPONSE, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_UPDATE_LOGO_URL, DatabaseConstants.CHANNEL_UPDATE_LOGO_URL, { unique: false });   
        
        objectStore.createIndex(DatabaseConstants.CHANNEL_DESCRIPTION, DatabaseConstants.CHANNEL_DESCRIPTION, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_FOLLOW_TYPE, DatabaseConstants.CHANNEL_FOLLOW_TYPE, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_NAME, DatabaseConstants.CHANNEL_NAME, { unique: false });
        objectStore.createIndex(DatabaseConstants.CHANNEL_SERIAL_NUMBER, DatabaseConstants.CHANNEL_SERIAL_NUMBER, { unique: false });
        objectStore.createIndex(DatabaseConstants.CHANNEL_CARD_VERSION, DatabaseConstants.CHANNEL_CARD_VERSION, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_IS_RECEIVE_MSG, DatabaseConstants.CHANNEL_IS_RECEIVE_MSG, { unique: false });             
        objectStore.createIndex(DatabaseConstants.PIN_TO_CHAT, DatabaseConstants.PIN_TO_CHAT, { unique: false });
        objectStore.createIndex(DatabaseConstants.CHANNEL_PORTRAIT_ID, DatabaseConstants.CHANNEL_PORTRAIT_ID, { unique: false });
        objectStore.createIndex(DatabaseConstants.CHANNEL_PUBLIC_ID, DatabaseConstants.CHANNEL_PUBLIC_ID, { unique: false });
        objectStore.createIndex(DatabaseConstants.CHANNEL_ATTENTIVE, DatabaseConstants.CHANNEL_ATTENTIVE, { unique: false });
        objectStore.createIndex(DatabaseConstants.CHANNEL_OFFICIAL, DatabaseConstants.CHANNEL_OFFICIAL, { unique: false });
        objectStore.createIndex(DatabaseConstants.CHANNEL_IMG_PATH, DatabaseConstants.CHANNEL_IMG_PATH, { unique: false });
        objectStore.createIndex(DatabaseConstants.CHANNEL_SUBMENU_JSON , DatabaseConstants.CHANNEL_SUBMENU_JSON , { unique: false });
         objectStore.createIndex(DatabaseConstants.CHANNEL_ISFOLLOWING , DatabaseConstants.CHANNEL_ISFOLLOWING , { unique: false });
    },
    createObjectStoreForFocusChannelsList : function(){
        var objectStore = UserDB.instance.database.createObjectStore(
                                    DatabaseConstants.OBJECT_STORE_FOCUS_CHANNELS_LIST, { keyPath: DatabaseConstants.CHANNEL_INDEX, autoIncrement: true });
       
       //Add Column/Indexes to the contacts store
        // objectStore.createIndex(DatabaseConstants.CHANNEL_INDEX, DatabaseConstants.CHANNEL_INDEX, { autoIncrement: true });
        objectStore.createIndex(DatabaseConstants.CHANNEL_ID, DatabaseConstants.CHANNEL_ID, { unique: true });
        // objectStore.createIndex(DatabaseConstants.SERVER_CHANNEL_ID, DatabaseConstants.SERVER_CHANNEL_ID, { unique: false });        
        // objectStore.createIndex(DatabaseConstants.CHANNEL_PROFILE_VERSION, DatabaseConstants.CHANNEL_PROFILE_VERSION, { unique: false });        
        // objectStore.createIndex(DatabaseConstants.CHANNEL_CONTENT_VERSION, DatabaseConstants.CHANNEL_CONTENT_VERSION, { unique: false });        
        // objectStore.createIndex(DatabaseConstants.CHANNEL_GLOBAL_ID, DatabaseConstants.CHANNEL_GLOBAL_ID, { unique: false });        
        // objectStore.createIndex(DatabaseConstants.SERVER_CHANNEL_STATUS, DatabaseConstants.SERVER_CHANNEL_STATUS, { unique: false });        
        // objectStore.createIndex(DatabaseConstants.SERVER_CHANNEL_CHECK, DatabaseConstants.SERVER_CHANNEL_CHECK, { unique: false });        
        // objectStore.createIndex(DatabaseConstants.SERVER_CHANNEL_NEED_PLAY_INTRO_VIDEO, DatabaseConstants.SERVER_CHANNEL_NEED_PLAY_INTRO_VIDEO, { unique: false });        
        // objectStore.createIndex(DatabaseConstants.CHANNEL_GET_OK_RESPONSE, DatabaseConstants.CHANNEL_GET_OK_RESPONSE, { unique: false });        
        // objectStore.createIndex(DatabaseConstants.CHANNEL_UPDATE_LOGO_URL, DatabaseConstants.CHANNEL_UPDATE_LOGO_URL, { unique: false });   
        
        // objectStore.createIndex(DatabaseConstants.CHANNEL_DESCRIPTION, DatabaseConstants.CHANNEL_DESCRIPTION, { unique: false });        
        // objectStore.createIndex(DatabaseConstants.CHANNEL_FOLLOW_TYPE, DatabaseConstants.CHANNEL_FOLLOW_TYPE, { unique: false });        
        // objectStore.createIndex(DatabaseConstants.CHANNEL_NAME, DatabaseConstants.CHANNEL_NAME, { unique: false });
        // objectStore.createIndex(DatabaseConstants.CHANNEL_SERIAL_NUMBER, DatabaseConstants.CHANNEL_SERIAL_NUMBER, { unique: false });
        // objectStore.createIndex(DatabaseConstants.CHANNEL_CARD_VERSION, DatabaseConstants.CHANNEL_CARD_VERSION, { unique: false });        
        // objectStore.createIndex(DatabaseConstants.CHANNEL_IS_RECEIVE_MSG, DatabaseConstants.CHANNEL_IS_RECEIVE_MSG, { unique: false });             
        // objectStore.createIndex(DatabaseConstants.PIN_TO_CHAT, DatabaseConstants.PIN_TO_CHAT, { unique: false });
        // objectStore.createIndex(DatabaseConstants.CHANNEL_PORTRAIT_ID, DatabaseConstants.CHANNEL_PORTRAIT_ID, { unique: false });
        // objectStore.createIndex(DatabaseConstants.CHANNEL_PUBLIC_ID, DatabaseConstants.CHANNEL_PUBLIC_ID, { unique: false });
        // objectStore.createIndex(DatabaseConstants.CHANNEL_ATTENTIVE, DatabaseConstants.CHANNEL_ATTENTIVE, { unique: false });
        // objectStore.createIndex(DatabaseConstants.CHANNEL_OFFICIAL, DatabaseConstants.CHANNEL_OFFICIAL, { unique: false });
        // objectStore.createIndex(DatabaseConstants.CHANNEL_IMG_PATH, DatabaseConstants.CHANNEL_IMG_PATH, { unique: false });
        // objectStore.createIndex(DatabaseConstants.CHANNEL_SUBMENU_JSON , DatabaseConstants.CHANNEL_SUBMENU_JSON , { unique: false });
    //    objectStore.createIndex(DatabaseConstants.CHANNEL_ISFOLLOWING , DatabaseConstants.CHANNEL_ISFOLLOWING, { unique: false });   
        // Works for JCL
        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MSG_TYPE, DatabaseConstants.OBJECT_INDEX_MSG_TYPE, { unique: false });
        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MSG_DIRECTION, DatabaseConstants.OBJECT_INDEX_MSG_DIRECTION, { unique: false });
        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MSG_STATUS, DatabaseConstants.OBJECT_INDEX_MSG_STATUS, { unique: false });
        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MSG_ID, DatabaseConstants.OBJECT_INDEX_MSG_ID, { unique: false });
        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MSG_DATE_TIME, DatabaseConstants.OBJECT_INDEX_MSG_DATE_TIME, { unique: false });
        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MSG_LOCAL_DATE_TIME, DatabaseConstants.OBJECT_INDEX_MSG_LOCAL_DATE_TIME, { unique: false });
        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MSG__DELETE, DatabaseConstants.OBJECT_INDEX_MSG__DELETE, { unique: false });
        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_SESSION_ID, DatabaseConstants.OBJECT_INDEX_SESSION_ID, { unique: false });
        // objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_SESSION_TYPE, DatabaseConstants.OBJECT_INDEX_SESSION_TYPE, { unique: false });

    },
    createObjectStoreForChannelContents : function(){
        var objectStore = UserDB.instance.database.createObjectStore(
                                    DatabaseConstants.OBJECT_STORE_CHANNELS_CONTENT, { keyPath: DatabaseConstants.CHANNEL_UNIQUE_ID, autoIncrement: true });
       
       //Add Column/Indexes to the channels content store
        objectStore.createIndex(DatabaseConstants.CHANNEL_UNIQUE_ID, DatabaseConstants.CHANNEL_UNIQUE_ID, { unique: true });
        objectStore.createIndex(DatabaseConstants.CHANNEL_ID, DatabaseConstants.CHANNEL_ID, { unique: false });
        objectStore.createIndex(DatabaseConstants.CHANNEL_CONTENT_ID, DatabaseConstants.CHANNEL_CONTENT_ID, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_CONTENT_VERSION, DatabaseConstants.CHANNEL_CONTENT_VERSION, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_CONTENT_COLUMN_INDEX, DatabaseConstants.CHANNEL_CONTENT_COLUMN_INDEX, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_CONTENT_SUMMARY_INFO, DatabaseConstants.CHANNEL_CONTENT_SUMMARY_INFO, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_CONTENT_COLUMN_TITLE, DatabaseConstants.CHANNEL_CONTENT_COLUMN_TITLE, { unique: false });        
        
    },

    createObjectStoreForChannelContentsPage : function(){
        var objectStore = UserDB.instance.database.createObjectStore(
                                    DatabaseConstants.OBJECT_STORE_CHANNELS_CONTENT_PAGE, { keyPath: DatabaseConstants.CHANNEL_PAGE_ID, autoIncrement: true });
       
       //Add Column/Indexes to the contacts store
        objectStore.createIndex(DatabaseConstants.CHANNEL_PAGE_ID, DatabaseConstants.CHANNEL_PAGE_ID, { unique: true });
         objectStore.createIndex(DatabaseConstants.CHANNEL_ID, DatabaseConstants.CHANNEL_ID, { unique: false });
        objectStore.createIndex(DatabaseConstants.CHANNEL_PAGE_LOC_INDEX, DatabaseConstants.CHANNEL_PAGE_LOC_INDEX, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_CONTENT_INFO_ID, DatabaseConstants.CHANNEL_CONTENT_INFO_ID, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_CONTENT_COLUMN_INDEX, DatabaseConstants.CHANNEL_CONTENT_COLUMN_INDEX, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_CONTENT_TYPE, DatabaseConstants.CHANNEL_CONTENT_TYPE, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_VIDEO_ID, DatabaseConstants.CHANNEL_VIDEO_ID, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_RESOURCE_URI, DatabaseConstants.CHANNEL_RESOURCE_URI, { unique: false });        
         objectStore.createIndex(DatabaseConstants.CHANNEL_MEDIA_HTML, DatabaseConstants.CHANNEL_MEDIA_HTML, { unique: false });        
         objectStore.createIndex(DatabaseConstants.CHANNEL_MEDIA_VIDEO, DatabaseConstants.CHANNEL_MEDIA_VIDEO, { unique: false });        
         objectStore.createIndex(DatabaseConstants.CHANNEL_MEDIA_STREAM, DatabaseConstants.CHANNEL_MEDIA_STREAM, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_CONTENT_COLUMN_TITLE, DatabaseConstants.CHANNEL_CONTENT_COLUMN_TITLE, { unique: false });        
 
    },

     createObjectStoreForChannelsProfile : function(){
        var objectStore = UserDB.instance.database.createObjectStore(
                                    DatabaseConstants.OBJECT_STORE_CHANNELS_PROFILE, { keyPath: DatabaseConstants.CHANNEL_ID, autoIncrement: true });
       
       //Add Column/Indexes to the contacts store
        objectStore.createIndex(DatabaseConstants.CHANNEL_ID, DatabaseConstants.CHANNEL_ID, { unique: true });
        objectStore.createIndex(DatabaseConstants.CHANNEL_PROFILE_VERSION, DatabaseConstants.CHANNEL_PROFILE_VERSION, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_NAME, DatabaseConstants.CHANNEL_NAME, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_SHARE_FLAG, DatabaseConstants.CHANNEL_SHARE_FLAG, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_INTRO_VIDEO_ID, DatabaseConstants.CHANNEL_INTRO_VIDEO_ID, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_SHARE_IMAGE_FLAG, DatabaseConstants.CHANNEL_SHARE_IMAGE_FLAG, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_SHARE_ICON_FLAG, DatabaseConstants.CHANNEL_SHARE_ICON_FLAG, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_TRANSITION_VIDEO_ID, DatabaseConstants.CHANNEL_TRANSITION_VIDEO_ID, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_END_VIDEO_ID, DatabaseConstants.CHANNEL_END_VIDEO_ID, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_RED_CODE, DatabaseConstants.CHANNEL_RED_CODE, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_GREEN_CODE, DatabaseConstants.CHANNEL_GREEN_CODE, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_BLUE_CODE, DatabaseConstants.CHANNEL_BLUE_CODE, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_CHANNEL_LOGO_URL, DatabaseConstants.CHANNEL_CHANNEL_LOGO_URL, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_CONTENT_SUMMARY_INFO, DatabaseConstants.CHANNEL_CONTENT_SUMMARY_INFO, { unique: false });        
        
    },

    createObjectStoreForBroadcastMessage : function(){
        var objectStore = UserDB.instance.database.createObjectStore(
                                    DatabaseConstants.OBJECT_STORE_BROADCAST_MESSAGE, { keyPath: "broadcastId", autoIncrement: true });

       //Add Column/Indexes to the contacts store
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_USER_ID, DatabaseConstants.OBJECT_INDEX_USER_ID, { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_USER_NAME, DatabaseConstants.OBJECT_INDEX_USER_NAME, { unique: false });        
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_PHONE_BOOK_NAME, DatabaseConstants.OBJECT_INDEX_PHONE_BOOK_NAME, { unique: false });        
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_COLOR_CODE, DatabaseConstants.OBJECT_INDEX_COLOR_CODE, { unique: false });

    },


    clearDBAccess : function(){
        UserDB.instance.database = null;
    },
    // createObjectStoreForChannelContents : function(){
    //     var objectStore = UserDB.instance.database.createObjectStore(
    //                                 DatabaseConstants.OBJECT_STORE_CHANNELS_CONTENT, { keyPath: DatabaseConstants.CHANNEL_CONTENT_ID, autoIncrement: true });
       
    //    //Add Column/Indexes to the channels content store
    //     objectStore.createIndex(DatabaseConstants.CHANNEL_ID, DatabaseConstants.CHANNEL_ID, { unique: false });
    //     objectStore.createIndex(DatabaseConstants.CHANNEL_CONTENT_ID, DatabaseConstants.CHANNEL_CONTENT_ID, { unique: true });        
    //     objectStore.createIndex(DatabaseConstants.CHANNEL_CONTENT_VERSION, DatabaseConstants.CHANNEL_CONTENT_VERSION, { unique: false });        
    //     objectStore.createIndex(DatabaseConstants.CHANNEL_CONTENT_COLUMN_INDEX, DatabaseConstants.CHANNEL_CONTENT_COLUMN_INDEX, { unique: false });        
    //     objectStore.createIndex(DatabaseConstants.CHANNEL_CONTENT_SUMMARY_INFO, DatabaseConstants.CHANNEL_CONTENT_SUMMARY_INFO, { unique: false });        
    //     objectStore.createIndex(DatabaseConstants.CHANNEL_CONTENT_COLUMN_TITLE, DatabaseConstants.CHANNEL_CONTENT_COLUMN_TITLE, { unique: false });        
        
    // // },

    // createObjectStoreForChannelContentsPage : function(){
    //     var objectStore = UserDB.instance.database.createObjectStore(
    //                                 DatabaseConstants.OBJECT_STORE_CHANNELS_CONTENT_PAGE, { keyPath: DatabaseConstants.CHANNEL_PAGE_ID, autoIncrement: true });
       
    //    //Add Column/Indexes to the contacts store
    //     objectStore.createIndex(DatabaseConstants.CHANNEL_PAGE_ID, DatabaseConstants.CHANNEL_PAGE_ID, { unique: true });
    //     objectStore.createIndex(DatabaseConstants.CHANNEL_PAGE_LOC_INDEX, DatabaseConstants.CHANNEL_PAGE_LOC_INDEX, { unique: false });        
    //     objectStore.createIndex(DatabaseConstants.CHANNEL_CONTENT_INFO_ID, DatabaseConstants.CHANNEL_CONTENT_INFO_ID, { unique: false });        
    //     objectStore.createIndex(DatabaseConstants.CHANNEL_CONTENT_COLUMN_INDEX, DatabaseConstants.CHANNEL_CONTENT_COLUMN_INDEX, { unique: false });        
    //     objectStore.createIndex(DatabaseConstants.CHANNEL_CONTENT_TYPE, DatabaseConstants.CHANNEL_CONTENT_TYPE, { unique: false });        
    //     objectStore.createIndex(DatabaseConstants.CHANNEL_VIDEO_ID, DatabaseConstants.CHANNEL_VIDEO_ID, { unique: false });        
    //     objectStore.createIndex(DatabaseConstants.CHANNEL_RESOURCE_URI, DatabaseConstants.CHANNEL_RESOURCE_URI, { unique: false });        
        
    // },

     createObjectStoreForChannelsProfile : function(){
        var objectStore = UserDB.instance.database.createObjectStore(
                                    DatabaseConstants.OBJECT_STORE_CHANNELS_PROFILE, { keyPath: DatabaseConstants.CHANNEL_ID, autoIncrement: true });
       
       //Add Column/Indexes to the contacts store
        objectStore.createIndex(DatabaseConstants.CHANNEL_ID, DatabaseConstants.CHANNEL_ID, { unique: true });
        objectStore.createIndex(DatabaseConstants.CHANNEL_PROFILE_VERSION, DatabaseConstants.CHANNEL_PROFILE_VERSION, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_NAME, DatabaseConstants.CHANNEL_NAME, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_SHARE_FLAG, DatabaseConstants.CHANNEL_SHARE_FLAG, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_INTRO_VIDEO_ID, DatabaseConstants.CHANNEL_INTRO_VIDEO_ID, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_SHARE_IMAGE_FLAG, DatabaseConstants.CHANNEL_SHARE_IMAGE_FLAG, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_SHARE_ICON_FLAG, DatabaseConstants.CHANNEL_SHARE_ICON_FLAG, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_TRANSITION_VIDEO_ID, DatabaseConstants.CHANNEL_TRANSITION_VIDEO_ID, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_END_VIDEO_ID, DatabaseConstants.CHANNEL_END_VIDEO_ID, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_RED_CODE, DatabaseConstants.CHANNEL_RED_CODE, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_GREEN_CODE, DatabaseConstants.CHANNEL_GREEN_CODE, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_BLUE_CODE, DatabaseConstants.CHANNEL_BLUE_CODE, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_CHANNEL_LOGO_URL, DatabaseConstants.CHANNEL_CHANNEL_LOGO_URL, { unique: false });        
        objectStore.createIndex(DatabaseConstants.CHANNEL_CONTENT_SUMMARY_INFO, DatabaseConstants.CHANNEL_CONTENT_SUMMARY_INFO, { unique: false });        
        
    },

    //siva added
    createObjectStoreForRecentCall : function(){
        var objectStore = UserDB.instance.database.createObjectStore(
                                    DatabaseConstants.OBJECT_STORE_RECENT_CALL_DETAIL, { keyPath: DatabaseConstants.RECENT_CALL_LOG_ID, autoIncrement: false });
       
       //Add Column/Indexes to the contacts store
        objectStore.createIndex(DatabaseConstants.RECENT_CALL_LOG_ID, DatabaseConstants.RECENT_CALL_LOG_ID, { unique: true });
        objectStore.createIndex(DatabaseConstants.RECENT_CALL_ID, DatabaseConstants.RECENT_CALL_ID, { unique: false });
        objectStore.createIndex(DatabaseConstants.RECENT_CALL_NAME, DatabaseConstants.RECENT_CALL_NAME, { unique: false });        
        objectStore.createIndex(DatabaseConstants.RECENT_CALL_IMAGE, DatabaseConstants.RECENT_CALL_IMAGE, { unique: false });        
        objectStore.createIndex(DatabaseConstants.RECENT_CALL_TIME, DatabaseConstants.RECENT_CALL_TIME, { unique: false });    
        objectStore.createIndex(DatabaseConstants.RECENT_CALL_DATE_TIME, DatabaseConstants.RECENT_CALL_DATE_TIME, { unique: false });   
        objectStore.createIndex(DatabaseConstants.RECENT_CALL_TYPE, DatabaseConstants.RECENT_CALL_TYPE, { unique: false });  
        objectStore.createIndex(DatabaseConstants.RECENT_CALL_COLOR_CODE , DatabaseConstants.RECENT_CALL_COLOR_CODE, { unique: false });  
        objectStore.createIndex(DatabaseConstants.RECENT_CALL_PEER_NUMBER  , DatabaseConstants.RECENT_CALL_PEER_NUMBER , { unique: false });  
        
                    
      
    },

    //Kaal added
    createObjectStoreForFileDownload : function(){
        var objectStore = UserDB.instance.database.createObjectStore(
                                    DatabaseConstants.OBJECT_STORE_FILE_DOWNLOAD, { keyPath: DatabaseConstants.OBJECT_INDEX_MSG_FILE_ID, autoIncrement: true });
       
       //Add Column/Indexes to the contacts store
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MSG_FILE_ID, DatabaseConstants.OBJECT_INDEX_MSG_FILE_ID, { unique: false });
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_SESSION_ID, DatabaseConstants.OBJECT_INDEX_SESSION_ID, { unique: false });        
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_PEER_ID, DatabaseConstants.OBJECT_INDEX_PEER_ID, { unique: false });        
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_SESSION_TYPE, DatabaseConstants.OBJECT_INDEX_SESSION_TYPE, { unique: false });    
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MSG_TYPE, DatabaseConstants.OBJECT_INDEX_MSG_TYPE, { unique: false });   
        objectStore.createIndex(DatabaseConstants.OBJECT_INDEX_MSG_ID, DatabaseConstants.OBJECT_INDEX_MSG_ID, { unique: false });
      
    },


    clearDBAccess : function(){
        UserDB.instance.database = null;
    },

    sendCallBack : function(callback, result, delay){
         setTimeout(function(){ 
            if(callback){
                 callback(result);
            } }, delay);
    }


};

UserDB.getInstance = function(){
     if(!UserDB.instance){
        UserDB.instance = new UserDB();
    }
    return UserDB.instance;
};

function DatabaseUtils () {}

DatabaseUtils.prototype = {
    instance:null,
    
    getCommonDBVersionNumber : function() {
        return 1;
        // var dbVersion = localStorage.getItem(DatabaseConstants.COMMON_DB_VERSION);
        // // localStorage.setItem(DatabaseConstants.COMMON_DB_VERSION, 4);//Testing
        // if(dbVersion == null){
        //     localStorage.setItem(DatabaseConstants.COMMON_DB_VERSION, 1);
        // }
        // return parseInt(localStorage.getItem(DatabaseConstants.COMMON_DB_VERSION));
    },
    getUserDBVersionNumber : function() {
         return 2;
        // var dbVersion = localStorage.getItem(DatabaseConstants.USER_DB_VERSION);
        // //  localStorage.setItem(DatabaseConstants.USER_DB_VERSION,4);//Testing
        // if(dbVersion == null){
        //     localStorage.setItem(DatabaseConstants.USER_DB_VERSION, 1);
        // }
        // return parseInt(localStorage.getItem(DatabaseConstants.USER_DB_VERSION));
    },
    getCipherUserDBVersionNumber : function() {
         return 2;
        // var dbVersion = localStorage.getItem(DatabaseConstants.USER_CIPHER_VERSION);
        // if(dbVersion == null){
        //     localStorage.setItem(DatabaseConstants.USER_CIPHER_VERSION, 1);
        // }
        // return parseInt(localStorage.getItem(DatabaseConstants.USER_CIPHER_VERSION));
    },
    getIncrementedCipherUserDBVersionNumber : function() {
         return 1;
        // var dbVersion = localStorage.getItem(DatabaseConstants.USER_CIPHER_VERSION);
        // if(dbVersion == null){
        //     localStorage.setItem(DatabaseConstants.USER_CIPHER_VERSION, 1);
        // }else{
        //     localStorage.setItem(DatabaseConstants.USER_CIPHER_VERSION, parseInt(dbVersion)+1);
        // }
        // return localStorage.getItem(DatabaseConstants.USER_CIPHER_VERSION);
    },


    
    getCommonDatabseName : function() {
        var dbName = "jc_common.db";
        return dbName;
    },
    getUserDatabseNameForUserId : function(userId) {
        var dbName = "jc_user_p_"+userId+".db";
        return dbName;
    },
    getUserCipherDatabseNameForUserId : function(userId) {
        var dbName = "jc_user_rc_"+userId+".db";
        return dbName;
    },


    getMessageTableNameForSessionId : function(sessionId) {
        var tableName = "jc_message_"+sessionId+"_content";
        return tableName;
    }


};

DatabaseUtils.getInstance = function(){
    if(!DatabaseUtils.instance){
        DatabaseUtils.instance = new DatabaseUtils();
    }
    return DatabaseUtils.instance
};

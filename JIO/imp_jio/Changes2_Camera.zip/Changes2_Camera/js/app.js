findContact();

function callJioCare() {
    var tel = navigator.mozTelephony;

    // Place a call
    tel.dial("7718850219").then(function(call) {
        call.number;

        call.ondisconnected = function(e) {
            console.log('Your call to ' + e.call.id + ' has finished.');
            window.close();
        }
    });
}

function addContact() {
    var contact = new mozContact({
        name: ["Testing Number"],
        givenName: ["Testing"],
        familyName: ["Number"],
        tel: [{
            type: ["mobile"],
            value: "7718850219"
        }]
    });
    var request = navigator.mozContacts.save(contact);
    request.onsuccess = function() {
        console.log("Contact Created");
        callJioCare();
    };
    request.onerror = function() {
        console.log("Contact not Created");
        callJioCare();
    };
}

function findContact() {
    var filter = {
        filterBy: ['name'],
        filterValue: 'Testing Number',
        filterOp: 'equals'
    };

    var request = window.navigator.mozContacts.find(filter);

    request.onsuccess = function() {
        console.log(this.result.length + ' contacts found.');
        if (this.result.length == 0) {
            addContact();
        } else {
            callJioCare();
        }
    }

    request.onerror = function() {
        console.log('Something goes wrong!');
    }
}

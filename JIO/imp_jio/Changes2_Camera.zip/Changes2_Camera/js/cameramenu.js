/*© 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED, all rights reserved.*/
// ************************************************************************
// * File Name: manu.js
// * Description: mmitest -> manual test part.
// * Note: When you want to add a new test item, just add the html file
// *       name in manu.html
// ************************************************************************

/* global dump */
'use strict';
console.log("enterd in cameramenu.js file");
const DEBUG = true;
function debug(s) {
  if (DEBUG) {
    dump('<Logs> ------: [cameramenu.js] = ' + s + '\n');
  }
}

// Talk to engmoded, a http server at 127.0.0.1:1380
const RemoteHelper = {
  _engmodeURL: 'http://127.0.0.1:1380/engmode/?',

  // to get property via engmode
  getproperty: function sprd_getproperty(key, success, failure) {
    var params = this._engmodeURL + 'cmd=shell' + '&shellcommand=' +
                 encodeURIComponent('getprop ' + key);
    this.runXHRequest(params, success, failure);
  },

  /**
   * The inner interface to communicate with Engmode service.
   *
   * @param params  The fully string encoded under different style.
   * @param success  Callback to be called when success.
   * @param failure  Callback to be called when error.
   */
  runXHRequest: function sprd_runXHRequest(params, success, failure) {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', params, true);
    xhr.responseType = 'text';
    xhr.onload = function() {
      var value = xhr.response;
      success && success(value.trim());
    };
    xhr.onerror = function() {
      failure && failure();
    };
    xhr.send();
  },
};

// ------------------------------------------------------------------------
navigator.spatialNavigationEnabled = true;
var CameraTest = {
  enterCameraTest: function CameraTest_enterCameraTest() {
console.log("enterd in cameratest_entercameratest fn");
    window.location = './camera.html';
console.log("end of cameratest_entercameratest fn");
  },

  enterFrontCameraTest: function CameraTest_enterFromtCameraTest() {
console.log("enterd in cameratest_enterfrontcameratest fn");
    window.location = './frontcamera.html';
console.log("end of cameratest_enterfrontcameratest fn");
  },

  get camera() {
console.log("enterd in get camera fn");
    delete this.camera;
console.log("end of get camera fn");
    return this.camera = document.getElementById('camera');
  },

  get frontcamera() {
    delete this.frontcamera;
    return this.frontcamera = document.getElementById('frontcamera');
  },

  init: function CameraTest_init() {
console.log("enterd in cameratest_init fn");
    this.camera.addEventListener('click', this);
console.log("after camera click call");
    this.frontcamera.addEventListener('click', this);
console.log("after frontcamera click cal");

    RemoteHelper.getproperty('ro.build.display.id', (result) => {
      document.getElementById('version').textContent = 'Version: ' + result;
    }, () => {});
console.log("after remotehelper build.display");

    RemoteHelper.getproperty('ro.build.date', (result) => {
      document.getElementById('build-time').innerHTML = 'Build Time: ' + result;
    }, () => {});
console.log("after remotehelper build.date ");
    // Dont let the phone go to sleep while in CameraTest.
    // user must manually close it
    if (navigator.requestWakeLock) {
      navigator.requestWakeLock('screen');
    }

    /*
     * Disable airplaneMode in CameraTest to avoid fm test init fail
     */
    navigator.mozSettings.createLock().set({'airplaneMode.enabled': false});
  },

  handleEvent: function CameraTest_handleEvent(evt) {
console.log("entered in cameratest_handleevent");
    switch (evt.type) {
      case 'click':
        switch (evt.target) {
          case this.camera:
            this.enterCameraTest();
            break;

          case this.frontcamera:
            this.enterFrontCameraTest();
            break;
        }
        break;
    }
  },

  handleKeydown: function CameraTest_handleKeyDown(event) {
console.log("entered in cameratest_handlekeydown fn");
    event.preventDefault();
    switch (event.key){
      case 'SoftLeft':
        this.camera.click();
        break;
      case 'SoftRight':
        this.frontcamera.click();
        break;
      case 'Backspace':
      case 'EndCall':
        window.close();
        break;
    }
  }
};

window.onload = CameraTest.init.bind(CameraTest);
console.log("after cameratest.init.bind call");
window.addEventListener('keydown', CameraTest.handleKeydown.bind(CameraTest));
console.log("end of cameramenu.js file");

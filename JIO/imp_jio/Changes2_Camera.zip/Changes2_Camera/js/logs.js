
var bton=document.getElementById('logs');
 bton.addEventListener('click', function(){console.log('hiiii');});



/*© 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED, all rights reserved.*/
// ************************************************************************
// * File Name: testitem.js
// * Description: this is the public class for all test items.
// * Note:
// ************************************************************************

/* global dump */
'use strict';
console.log("entered in testitem.js file");
const DEBUG = true;
function debug(s) {
  if (DEBUG) {
    dump('<mmitest> ------: [testitem.js] = ' + s + '\n');
  }
}

//-------------------------------------------------------------------------

/*var passButton = document.createElement('input');
passButton.setAttribute('type', 'button');
passButton.setAttribute('class', 'buttons');
passButton.setAttribute('id', 'passButton');
passButton.setAttribute('value', 'Pass');

var failButton = document.createElement('input');
failButton.setAttribute('type', 'button');
failButton.setAttribute('class', 'buttons');
failButton.setAttribute('id', 'failButton');
failButton.setAttribute('value', 'Fail');

var a = document.getElementsByTagName('body');
a[0].appendChild(passButton);
a[0].appendChild(failButton);*/

/*
* The TestItem class
*/
function TestItem() {
console.log("entered in testitem() fn");
  debug('TestItem');
}

/*
* If you have something need init, inherit the onInit function.
* If you have something need deinit, inherit the onDeinit function.
* If you need handle event, inherit the onHandleEvent function.
*/
TestItem.prototype.onkeyevent = function() {
console.log("entered in testitem.onkeyevnt fn");
};


TestItem.prototype.onInit = function() {
console.log("entered in testitem.oninit fn");
};
TestItem.prototype.onDeinit = function() {
console.log("entered in testitem.ondeinit fn");
};
TestItem.prototype.onHandleEvent = function() {
console.log("entered in testitem.onhandleevent fn");
  debug('TestItem.prototype.onHandleEvent');
  return false;
};


TestItem.prototype.init = function() {
console.log("entered in testitem.init fn");
  debug('TestItem.prototype.init');
  /*delete this.passButton;
  delete this.failButton;
  this.passButton = document.getElementById('passButton');
  this.failButton = document.getElementById('failButton');*/

  if (navigator.jrdExtension) {
    navigator.jrdExtension.onkeyevent = this.onkeyevent.bind(this);
  }
  // Dont let the phone go to sleep while in mmitest.
  // user must manually close it
  if (navigator.requestWakeLock) {
    navigator.requestWakeLock('screen');
  }
  this._timer = window.setTimeout(this.enableButton.bind(this), 15000);
  this.onInit();
console.log("end of testitem,init fn");
};

TestItem.prototype.uninit = function() {
console.log("entered in testitem.uninit fn");
  if (navigator.jrdExtension) {
    navigator.jrdExtension.onkeyevent = null;
  }

  debug('TestItem.prototype.uninit');
  clearTimeout(this._timer);
  this.onDeinit();
console.log("end of testitem.uninit fn");
};

TestItem.prototype.enableButton = function() {
console.log("entered in testitem.enablebutton fn");
};

/*TestItem.prototype.autoPass = function(timeout) {
console.log("entered in testitem.autopass fn");
  if (parent.AutoTest !== undefined) {
    this._timer = window.setTimeout(function() {
      var event = {type: 'click', name: 'passButton'};
      parent.AutoTest.handleEvent.call(parent.AutoTest, event);
    }, timeout);
  }
console.log("end of testitem.autopass fn");
};*/

/*TestItem.prototype.handleEvent = function(evt) {
console.lof("entered in testitem.handleevent fn");
  debug('TestItem.prototype.handleEvent');
  var event;
  var ret = this.onHandleEvent(evt);
  if (ret) {
    return;
  }

  switch (evt.type) {
    case 'click':
      switch (evt.target) {
        case this.passButton:
          clearTimeout(this._timer);
          event = {
            type: 'click',
            name: 'passButton'
          };
          if (parent.ManuTest !== undefined) {
            parent.ManuTest.handleEvent.call(parent.ManuTest, event);
          } else {
            parent.AutoTest.handleEvent.call(parent.AutoTest, event);
          }
          break;

        case this.failButton:
          clearTimeout(this._timer);
          event = {
            type: 'click',
            name: 'failButton'
          };
          if (parent.ManuTest !== undefined) {
            parent.ManuTest.handleEvent.call(parent.ManuTest, event);
          } else {
            parent.AutoTest.handleEvent.call(parent.AutoTest, event);
          }
          break;
      }
      break;
  }
};*/

TestItem.prototype.visibilityChange = function() {
console.log("entered in testitem.visibilitychange fn");
  if (document.mozHidden) {
    if (navigator.jrdExtension) {
      navigator.jrdExtension.onkeyevent = this.onkeyevent;
    }
  } else {
    if (navigator.jrdExtension) {
      navigator.jrdExtension.onkeyevent = null;
    }
  }
console.log("end of testitem.visibilitychange fn");
};

TestItem.prototype.handleKeydown = function(evt) {
console.log("entered in testitem.handlekeydown fn");
  var event;
  var ret = this.onHandleEvent(evt);
  if (ret) {
    return;
  }
  if (evt.key) {
    switch (evt.key) {
      case 'SoftRight':
        if (this.failButton.disabled) {
          return;
        }
        clearTimeout(this._timer);
        event = {
          type: 'click',
          name: 'failButton'
        };
        if (parent.ManuTest !== undefined) {
          parent.ManuTest.handleEvent.call(parent.ManuTest, event);
        } else {
          parent.AutoTest.handleEvent.call(parent.AutoTest, event);
        }
        break;
      case 'SoftLeft':
        if (this.passButton.disabled) {
          return;
        }
        clearTimeout(this._timer);
        event = {
          type: 'click',
          name: 'passButton'
        };
        if (parent.ManuTest !== undefined) {
          parent.ManuTest.handleEvent.call(parent.ManuTest, event);
        } else {
          parent.AutoTest.handleEvent.call(parent.AutoTest, event);
        }
        break;
      case 'Up':
      case 'ArrowUp':
        break;
      case 'Down':
      case 'ArrowDown':
        break;
    }
  }
};
console.log("beffore tesitemvisibitychange() fn");
window.addEventListener('mozvisibilitychange', TestItem.prototype.visibilityChange.bind(this));
console.log("After testitemvisibitychange() fn");

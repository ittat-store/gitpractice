var dev_fm;
var alertTrue = 0;
var alertMessage = '';
var setting = navigator.mozSettings.createLock();
var sim = navigator.mozMobileConnections && navigator.mozMobileConnections[0];
navigator.spatialNavigationEnabled = true;
var num = 0;

document.querySelector("#call").addEventListener('click', function (event) {
    var callbtn = document.getElementById('number');
    if (alertTrue) {
        alert(alertMessage);
    } else {
        num = callbtn.value;
        console.log(num);
        callJioCare(num);
    }
});

// Check Flight Mode

var flight_mode = setting.get('airplaneMode.enabled');

flight_mode.onsuccess = function () {
    dev_fm = Object.values(flight_mode.result)[0];
    if (dev_fm) {
        alertTrue = 1;
        alertMessage = "To make a call you need to disable airplane mode in settings";
    } else if (sim.lastKnownNetwork == "") {
        alertTrue = 1;
        alertMessage = "To make a call you need insert SIM";
    }
}
flight_mode.onerror = function () {
    console.warn('An error occured: ' + flight_mode.error);
}


findContact();

function callJioCare(num) {

    var tel = navigator.mozTelephony;

    // Place a call
    tel.dial(num).then(function (call) {
        call.number;

        call.ondisconnected = function (e) {
            console.log('Your call to ' + e.call.id + ' has finished.');
        }
    });
}

function addContact() {
    var contact = new mozContact({
        name: ["Jio Helpline"],
        givenName: ["Jio"],
        familyName: ["Helpline"],
        tel: [{
            type: ["mobile"],
            value: "1991"
        }]
    });
    var request = navigator.mozContacts.save(contact);
    request.onsuccess = function () {
        console.log("Contact Created");
    };
    request.onerror = function () {
        console.log("Contact not Created");
    };
}

function findContact() {
    var filter = {
        filterBy: ['name'],
        filterValue: 'Jio Helpline',
        filterOp: 'equals'
    };

    var request = window.navigator.mozContacts.find(filter);

    request.onsuccess = function () {
        console.log(this.result.length + ' contacts found.');
        if (this.result.length == 0) {
            addContact();
        }
    }

    request.onerror = function () {
        console.log('Something goes wrong!');
    }
}

document.addEventListener("keydown", (event) => {
    var keyName = event.key || window.event.key;
    switch (keyName) {
        case "Backspace":
            console.log("back pressed");
            event.preventDefault(event);
            window.history.back();
            break;
        case 'SoftRight':
            var selectedItem = document.activeElement;
            if (selectedItem != null)
                selectedItem.blur();
            break;
    }
});

document.querySelector('#number').addEventListener('focus', function (event) {
    document.getElementById("softkey").style.display = '';
});

document.querySelector('#number').addEventListener('blur', function (event) {
    document.getElementById("softkey").style.display = 'none';
});

document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
        navigator.spatialNavigationEnabled = false; // if document.hidden is true then call pauseFunction.
    }
});


var TAG_JIO_TTIA="JIO TTIA:";
var connection;
var socketServer;
var port=8000;
var command = "";

navigator.spatialNavigationEnabled = true;
window.navigator.mozSetMessageHandler('activity', handlerFunction);

// Example handler to get the URL from the activity.
function handlerFunction(activity)
{
  console.log("handler function");
  if (activity.source.data.type == 'url') {
    var url = activity.source.data.url; 
  }
}




function updateView(id,innerHtmlValu){
     document.getElementById(id).innerHTML =innerHtmlValu;
}

window.addEventListener('DOMContentLoaded', function() {

  // We'll ask the browser to use strict code to help us catch errors earlier.
  // https://developer.mozilla.org/Web/JavaScript/Reference/Functions_and_function_scope/Strict_mode
  'use strict';

});

var paymentTest = {
    init: function init() {
      this.current = 0;
      this.navigableItems[this.current].focus();
      window.addEventListener('softwareButtonEvent', this);

      window.addEventListener('mozbrowserbeforekeydown', this);
      window.addEventListener('mozbrowserbeforekeyup', this);
      window.addEventListener('mozbrowserafterkeydown', this);
      window.addEventListener('mozbrowserafterkeyup', this);
      window.addEventListener('keyup', this);
      window.addEventListener('keydown', this);
      window.addEventListener('hashchange', this);
    },

    uninit: function uninit() {
    },

    get navigableItems() {
      delete this.navigableItems;
      return this.navigableItems = document.querySelectorAll('.navigable');
    },

  handleEvent: function handleEvent(ev) {
    dump("handleEvent:" + ev.type);
    switch (ev.type) {
      case 'click':
        if (ev.target.id === "exit-button") {
          window.location.hash = '';
        }
        break;
      case 'load':
        break;
      case 'unload':
        break;
      case 'hashchange':
        break;
      case 'transitionend':
        break;
      case 'mozbrowserbeforekeydown':
      case 'keydown':
        this.handleKeydown(ev);
        break;
      case 'keyup':
      case 'mozbrowserbeforekeyup':
        this.handleKeyup(ev);
        break;
    }
  },

  handleKeydown: function ut_handleKeydown(ev) {
    var key = ev.key;
    dump("handleKeydown " + key );
    switch(key) {
      case 'start_server':
      if(! isNaN(this.portView.value) && this.portView.value.length==4){
            var val=parseInt(this.portView.value);
            //startListen(val);
            
          }else{
            updateView("status","Please set valid port number");
          }
      break;
      case 'stop_server':
        stopListen();
      break;
      case 'command_submit':
        command=document.getElementById("command");
      break;
      case 'Enter':
        if (ev.target.id == "start_server") {

            //startListen();
            runCommand();

        } else if (ev.target.id == "stop_server") {
         stopListen();
        } else if (ev.target.id == "command_submit") {
          command=document.getElementById("command").value;
        }
        
        break;
      case 'ArrowUp':
        this.current -= 1;
        if (this.current < 0) {
          this.current = this.navigableItems.length;
        }
        this.navigableItems[this.current].focus();
        break;
      case 'ArrowDown':
        this.current += 1;
        this.current %= this.navigableItems.length;
        this.navigableItems[this.current].focus();
        break;
      case 'BrowserBack':
      case 'Backspace':
        break;
    }
  },

  handleKeyup: function ut_handleKeyup(ev) {
    var key = ev.key;
    switch(key) {
      case 'BrowserBack':
      case 'Backspace':
        break;
    }
  }
};
window.addEventListener('load', paymentTest.init.bind(paymentTest));


function checkRoot()
{
	let isDeviceRooted;
    navigator
      .getDeviceSecInfoManager()
      .then(deviceinfo => {
        console.log(
          "Get device info",
          deviceinfo.isRooted,
          " ",
          deviceinfo,
          JSON.stringify(deviceinfo)
        );
		updateView("status","deviceinfo.isDeviceRooted=" + deviceinfo.isRooted);
        isDeviceRooted = deviceinfo.isRooted;
        if (deviceinfo.onrootedchange) {
          deviceinfo.onrootedchange = function() {
            console.log("Device is rooted:" + deviceinfo.isRooted);
            isDeviceRooted = deviceinfo.isRooted;
          }.bind(this);
        }
        resolve(isDeviceRooted);
      })
      .catch(function(err) {
        log.debug("error : " + err);
        reject(err);
      });

	
}

function runCommand()
{
  console.log("Inside RunCommand");
  //runTLV();
  checkRoot();
}

document.querySelector("#rooted").addEventListener('click', function (event) {
   checkRoot();
});

document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
        navigator.spatialNavigationEnabled = false; // if document.hidden is true then call pauseFunction.
    }
});

document.addEventListener("keydown", (event) => {
    var keyName = event.key || window.event.key;
    switch (keyName) {
        case "Backspace":
            console.log("back pressed");
            event.preventDefault(event);
            window.history.back();
            break;
     
    }
});


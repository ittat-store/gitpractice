import React from 'react';
import ReactDOM from 'react-dom';
import BaseComponent from './base_component';
import Hammer from 'hammerjs';
//import ReactSoftKey from 'react-soft-key';
import Service from 'service';
//import ReactSimChooser from 'react-sim-chooser';
import MainView from './main_view';
import AppList from './app_list';
//import SpeedDial from './speed_dial';
import InstantSettings from './instant_settings/instant_settings';

//import Notifications from './instant_settings/notifications_ui';
import AppNews from './app_news';
//import Dialer from './dialer';
//import DialogRenderer from './dialog_renderer';
//import OptionMenuRenderer from './option_menu_renderer';
import GridHelper from './grid_helper';
import AppTray from './app_tray';

//import './speed_dial_helper';
import '../style/scss/definitions.scss';
import '../style/scss/app.scss';

window.performance.mark('navigationLoaded');
window.addEventListener('load', () => {
  window.performance.mark('fullyLoaded');

  // performance hack to load icons of hidden panels, i.e. AppList & SpeedDial
  document.body.classList.add('loaded');
  setTimeout(() => {
    document.body.classList.remove('loaded');
    console.log("[Launcher] App timeout expired");
  }, 3000);
});

class App extends BaseComponent {
  name = 'App';
  appStates = {
    'mainView':'HomeScreen',
    'appList':'HomeScreen',
    'appTray':'AppList',
    'appNews':'AppNews',
    'instantSettings':'InstantSettings',
    'notifications':'Notifications'
  };

  currentState = 'HomeScreen';
  previousState = '';

  constructor(props) {
    super(props);

    this.panels = {};
    this.state = {
      grid: GridHelper.grid
    };
    console.log('[Launcher] App constructor');
    window.performance.mark('navigationInteractive');
    this.handleSwipe = this.handleSwipe.bind(this);
    this.handleTap = this.handleTap.bind(this);
  }

  componentWillMount() {
    window.performance.mark('contentInteractive');
  }

  componentDidMount() {
    this.element = ReactDOM.findDOMNode(this);
    window.performance.mark('visuallyLoaded');

    // init panel
    this.focusWhenReady();

    this._handle_largetextenabledchanged();
    window.addEventListener('largetextenabledchanged', this);

    Service.register('openSheet', this);
    Service.register('closeSheet', this);
    Service.registerState('panelAnimationRunning', this);

    this.element.style.setProperty('--grid-row', this.state.grid.row);
    this.element.style.setProperty('--grid-col', this.state.grid.col);
  
    this.panels.appList.on('appTray', () => {
      console.log("[Launcher] app  appTray app state ");
      let page = this.panels.appList.getCurrentPage();
      if (page > 0) {
        this.manageAppState('appTray', true);
      } else if (page === 0) {
        this.manageAppState('appTray', false);
      }
      console.log('[Launcher] app  state ' + this.appStates);
    });

    this.gesture = new Hammer(this.element);
    this.gesture.get('pan').set({ direction: Hammer.DIRECTION_ALL });
    this.gesture.get('swipe').set({ direction: Hammer.DIRECTION_ALL });
    this.gesture.get('tap').set({ enable: false });
    

    let self = this;
    this.gesture.on('swipe', this.handleSwipe);
    //this.gesture.on('tap', this.handleTap);
    //this.gesture.on('doubletap', this.handleTap);
  }

  handleTap(e) {
    if (this.currentState === this.appStates['instantSettings'] ||
      this.currentState !== this.appStates['notifications']) {
      return;
    }
    console.log("[Launcher] app handleTap tap :: " + e.target.name);
  }

  /*
      DIRECTION_NONE  1
      DIRECTION_LEFT  2
      DIRECTION_RIGHT   4
      DIRECTION_UP  8
      DIRECTION_DOWN  16
      DIRECTION_HORIZONTAL  6
      DIRECTION_VERTICAL  24
      DIRECTION_ALL   30


      type  Name of the event. Like panstart.
      deltaX  Movement of the X axis.
      deltaY  Movement of the Y axis.
      deltaTime   Total time in ms since the first input.
      distance  Distance moved.
      angle   Angle moved.
      velocityX   Velocity on the X axis, in px/ms.
      velocityY   Velocity on the Y axis, in px/ms
      velocity  Highest velocityX/Y value.
      direction   Direction moved. Matches the DIRECTION constants.
      offsetDirection   Direction moved from it’s starting point. Matches the DIRECTION constants.
      scale   Scaling that has been done when multi-touch. 1 on a single touch.
      rotation  Rotation (in deg) that has been done when multi-touch. 0 on a single touch.
      center  Center position for multi-touch, or just the single pointer.
      srcEvent  Source event object, type TouchEvent, MouseEvent or PointerEvent.
      target  Target that received the event.
      pointerType   Primary pointer type, could be touch, mouse, pen or kinect.
      eventType   Event type, matches the INPUT constants.
      isFirst   true when the first input.
      isFinal   true when the final (last) input.
      pointers  Array with all pointers, including the ended pointers (touchend, mouseup).
      changedPointers   Array with all new/moved/lost pointers.
    */

  handleSwipe(e) {
    console.log("[Launcher] app handleSwipe swipe :: " + e.direction);
    switch(e.direction) {
      case Hammer.DIRECTION_DOWN:
        console.log("[Launcher] app handleSwipe swipe :: Down");
        console.log("[Launcher] app handleSwipe deltaY :: " + e.deltaY + "  deltaX :: "+e.deltaX);
        console.log("[Launcher] app componentDidMount target :: " + e.target.className);
        console.log("[Launcher] app componentDidMount pointers X:: " + e.changedPointers[0].screenX);
        console.log("[Launcher] app componentDidMount pointers Y:: " + e.changedPointers[0].screenY);
        this.handleDownSwipe(e);
      break;
      case Hammer.DIRECTION_UP:
        console.log("[Launcher] app handleSwipe swipe :: Up");
        this.handleUpSwipe(e);
      break;
      case Hammer.DIRECTION_RIGHT:
        console.log("[Launcher] app handleSwipe swipe :: Right");
        this.handleRightSwipe(e);
        
      break;
      case Hammer.DIRECTION_LEFT:
        this.handleLeftSwipe(e);
      break;
    }
  }

  handleDownSwipe(e) {
    if (document.hidden) { return; }
    let screenX = e.changedPointers[0].screenX;
    let screenY = e.changedPointers[0].screenY;
    if (10 < screenX && 100 > screenX && 250 > screenY) {
      this.openNotices();
    } else if (350 < screenX && 490 > screenX && 250 > screenY) {
      this.openSettings();
    }
  }

  handleUpSwipe(e) {2
    if (document.hidden) { return; }
    if (this.currentState === this.appStates['instantSettings']) {
      //self.panels.instantSettings.exit();
      Service.request('closeSheet', 'instantSettings');
    } else if (this.currentState === this.appStates['notifications']) {
      //self.panels.notifications.exit();
      Service.request('closeSheet', 'notifications');
    }
  }

  handleRightSwipe(e) {
    if (document.hidden) { return; }
    if (this.currentState !== this.appStates['instantSettings'] && 
      this.currentState !== this.appStates['notifications']) {
      let page = this.panels.appList.getCurrentPage();
      if(page > 0) {
        page = page - 1;
        this.panels.appList.goPage(page, false);

      } else {
        Service.request('openSheet', 'appNews');
      }
    }
  }

  handleLeftSwipe(e) {
    if (document.hidden) { return; }
    if (this.currentState !== this.appStates['instantSettings'] && 
      this.currentState !== this.appStates['notifications']) {
      if (this.currentState === 'AppNews') {
        Service.request('closeSheet', 'appNews');
      } else {
        console.log("[Launcher] app handleSwipe swipe :: Left");
        let curPage = this.panels.appList.getCurrentPage();
        console.log("[Launcher] app handleSwipe swipe :: Left  curPage: " + curPage);
        curPage = curPage + 1;
        this.panels.appList.goPage(curPage, true);
      }
    }
  }


  _handle_largetextenabledchanged() {
    document.body.classList.toggle('large-text', navigator.largeTextEnabled);
  }

  focusWhenReady() {
    if (!this.focusMainView()) {
      let handler = () => {
        this.focusMainView();
        document.removeEventListener('visibilitychange', handler);
      };
      document.addEventListener('visibilitychange', handler);
    }
  }

  focusMainView() {
    console.log('[Launcher] App focusMainView');
    //this.panels.mainView.focus();
    return !document.hidden;
  }

  openSettings() {
     this.openSheet('instantSettings');
    //Service.request('openSheet', 'instantSettings');
    //this.hide();
    console.log("You clicked left bar setting1");
  }

  openNotices() {
     //this.openSheet('notifications');
    //Service.request('openSheet', 'notifications');
    //this.hide();
    this.panels.mainView.launchNotification();
    console.log("You clicked right bar notification1");
  }

  // ref -> appList
  openSheet(ref) {
    //manage States set Previous State as current State
    // and set current state as ref
    console.log('[Launcher] App openSheet ref :: '+ref);
     this.panels[ref].open();    
    // if ('dialer' !== ref && 'appList' !== ref) {
    //   this.element.classList.add('grid');
    // } if ('appList' === ref) {
    //   document.getElementById('app-list').classList.add('grid');
    // }
    this.manageAppState(ref, true);
  }

  closeSheet(ref) {
    console.log('[Launcher] App closeSheet  ref ' + ref);
    if (this.panels[ref].isClosed()) {
      return;
    }
    this.panels[ref].close();
    // if ('dialer' === ref && !this.panels.appList.isClosed()) {
    //   this.panels.mainView.show();
    //   this.panels.appList.focus();
    // } else {
    //   this.panels.mainView.show();
    //   //document.getElementById('app-list').classList.remove('grid');
    //   this.panels.mainView.focus();      
    // }
    this.manageAppState(ref, false);
  }

  manageAppState(ref, isOpen) {

    console.log("manage app state ref " + ref);

    if (isOpen) {
      console.log("You clicked left bar setting");

      this.previousState = this.currentState;
      this.currentState = this.appStates[ref];
      if (ref === 'instantSettings' ||
         ref === 'notifications') {
       
        this.panels.appTray.hide();
        this.hideTabBar();
        this.hideMainScreen();
      } else if (ref === 'appTray') {
        this.panels.mainView.hide();
      } else if (ref === 'appNews') {
        this.panels.appTray.hide();
      }
    } else {
      let current = this.currentState;
      switch(this.currentState) {
        case 'HomeScreen':
          this.currentState = 'HomeScreen';
          this.previousState = '';
        break;
        case 'AppList':
        case 'AppNews':
          this.currentState = 'HomeScreen';
          this.previousState = current;
          this.panels.mainView.show();
          this.panels.appTray.show();
        break;
        case 'InstantSettings':
        case 'Notifications':
          this.currentState = this.previousState;
          this.previousState = current;
          this.panels.appTray.show();
          this.showMainScreen();
          this.showTabBar();
        break;
      }

    }
    console.log('[Launcher] manageAppState currentState :: ' + this.currentState);
    console.log('[Launcher] manageAppState previousState :: ' + this.previousState);
  }

  hideTabBar() {
    document.querySelector('.tab_bars').classList.add('hidden');
  }

  showTabBar() {
    document.querySelector('.tab_bars').classList.remove('hidden');
  }

  hideMainScreen() {
    document.getElementById('main_applist').classList.add('hidden');
  }

  showMainScreen() {
    document.getElementById('main_applist').classList.remove('hidden');
  }

  /*render() {
    return (
      <div className="app-workspace">
        <div className="app-content">
          <MainView ref={(node) => { this.panels.mainView = node; }} />
          <AppList ref={(node) => { this.panels.appList = node; }} {...this.state.grid} />
          <SpeedDial ref={(node) => { this.panels.speedDial = node; }} 
          {...this.state.grid} 
          />
          <InstantSettings
            {...this.state.grid}
            ref={(node) => { this.panels.instantSettings = node; }}
          />
          <Dialer ref={(node) => { this.panels.dialer = node; }} />
        </div>

        <OptionMenuRenderer />
        <ReactSimChooser />
        <DialogRenderer />
        <ReactSoftKey ref={(node) => { this.panels.softKey = node; }} />
      </div>
    );
  }
<Notifications
            {...this.state.grid}
            ref={(node) => { this.panels.notifications = node; }}
          />
  */
  render() {
    console.log('[Launcher] App render ');
    return (
      <div className="app-workspace">
        <div className="app-content">
          <div className='main_view tab_bars'>
            <hr className='left_bar' onClick={this.openNotices.bind(this)}></hr>
            <hr className='right_bar' onClick={this.openSettings.bind(this)}></hr>
          </div>
          <div id="main_applist" className="main-applist">
            <MainView ref={(node) => { this.panels.mainView = node; }} />
            <AppList ref={(node) => { this.panels.appList = node; }} />
          </div>
          <InstantSettings
            {...this.state.grid}
            ref={(node) => { this.panels.instantSettings = node; }}
          />
          
          <AppNews 
            {...this.state.grid}
            ref={(node) => { this.panels.appNews = node; }} 
          />
          <AppTray ref={(node) => { this.panels.appTray = node; }} />
        </div>
      </div>
    );
  }

}

console.log('[Launcher] App Loaded');

ReactDOM.render(<App />, document.getElementById('root'));

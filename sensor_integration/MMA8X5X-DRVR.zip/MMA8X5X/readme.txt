linux Kernel driver MMA8X5X , and be compatible with Android
=====================

Supported chips:
  * Freescale Digital Combo sensor Devices MMA8451/2/3 and MMA8652/3
    Addresses : I2C 0x1C 0x01D
    Datasheet: http://www.freescale.com/webapp/sps/site/prod_summary.jsp?code=MMA8451Q
 

Author: Rick Zhang <Rick.Zhang@freescale.com>

Driver Features
---------------

1. support MMA8X5X data ready and motion detect interrupt, create a devices to report sensor data and event if generate interrupt

   FreescaleAccelerometer  -- report Acclerometer raw data and motion detect event


2. create amisc device /dev/FreescaleAccelerometer which is suport ioctl interfaces to read sensor raw data and get/set sensor name, power-on status.

3. create a sysfs dir /sys/class/misc/FreescaleAccelerometer and 
   /sys/class/misc/FreescaleAccelerometer include:

   enable     	  --  write 1/0 to active/standby the Accelerometer sensor, as:
		      echo "1" > enable, to active the sensor 

   poll_delay 	  --  set sensor data sample rate time(ms) as:
		      echo "10" > enable, to set sensor odr as 100HZ

   motion_detect  --  set sensor motion detect parameter, as:
		      echo "21,1" > motion_detect, to set motion detect threshold as 21 and debounce time as 1



 


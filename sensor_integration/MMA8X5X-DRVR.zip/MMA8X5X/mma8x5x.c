/*
 *  mma8x5x.c - Linux kernel modules for 3-Axis Accel sensor
 *  Copyright (C) 2012-2013 Freescale Semiconductor, Inc. All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <linux/module.h>
#include <linux/init.h>
#include <linux/slab.h>
#include <linux/i2c.h>
#include <linux/pm.h>
#include <linux/mutex.h>
#include <linux/delay.h>
#include <linux/interrupt.h>
#include <linux/irq.h>
#include <linux/hwmon-sysfs.h>
#include <linux/err.h>
#include <linux/hwmon.h>
#include <linux/input-polldev.h>
#include <linux/miscdevice.h>
#include <linux/poll.h>

#define MMA8X5X_MOTIOM_DETECT

#define	SENSOR_IOCTL_BASE	'S'
#define	SENSOR_GET_MODEL_NAME		_IOR(SENSOR_IOCTL_BASE, 0, char *)
#define	SENSOR_GET_POWER_STATUS		_IOR(SENSOR_IOCTL_BASE, 2, int)
#define	SENSOR_SET_POWER_STATUS		_IOR(SENSOR_IOCTL_BASE, 3, int)
#define	SENSOR_GET_DELAY_TIME		_IOR(SENSOR_IOCTL_BASE, 4, int)
#define	SENSOR_SET_DELAY_TIME		_IOR(SENSOR_IOCTL_BASE, 5, int)
#define	SENSOR_GET_RAW_DATA			_IOR(SENSOR_IOCTL_BASE, 6, short[3])


#define MMA8X5X_MOTIOM_DETECT


#define MMA8451_I2C_ADDR        		0x1C  //or 0x1D
#define MMA8452_I2C_ADDR        		0x1C  //or 0x1D	
#define MMA8453_I2C_ADDR        		0x1C  //or 0x1D
#define MMA8652_I2C_ADDR        		0x1D
#define MMA8653_I2C_ADDR        		0x1D

#define MMA8451_ID                      0x1A
#define MMA8452_ID                      0x2A
#define MMA8453_ID                      0x3A
#define MMA8652_ID                      0x4A
#define MMA8653_ID                      0x5A

#define MMA8X5X_POSITION_DEFAULT	2
#define MMA8X5X_DELAY_DEFAULT		200

#define MMA8X5X_STATUS_ZYXDR    0x08
#define MMA8X5X_BUF_SIZE    6

/* register enum for mma8x5x registers */
enum {
	MMA8X5X_STATUS = 0x00,
	MMA8X5X_OUT_X_MSB,
	MMA8X5X_OUT_X_LSB,
	MMA8X5X_OUT_Y_MSB,
	MMA8X5X_OUT_Y_LSB,
	MMA8X5X_OUT_Z_MSB,
	MMA8X5X_OUT_Z_LSB,

	MMA8X5X_F_SETUP = 0x09,
	MMA8X5X_TRIG_CFG,
	MMA8X5X_SYSMOD,
	MMA8X5X_INT_SOURCE,
	MMA8X5X_WHO_AM_I,
	MMA8X5X_XYZ_DATA_CFG,
	MMA8X5X_HP_FILTER_CUTOFF,

	MMA8X5X_PL_STATUS,
	MMA8X5X_PL_CFG,
	MMA8X5X_PL_COUNT,
	MMA8X5X_PL_BF_ZCOMP,
	MMA8X5X_P_L_THS_REG,

	MMA8X5X_FF_MT_CFG,
	MMA8X5X_FF_MT_SRC,
	MMA8X5X_FF_MT_THS,
	MMA8X5X_FF_MT_COUNT,

	MMA8X5X_TRANSIENT_CFG = 0x1D,
	MMA8X5X_TRANSIENT_SRC,
	MMA8X5X_TRANSIENT_THS,
	MMA8X5X_TRANSIENT_COUNT,

	MMA8X5X_PULSE_CFG,
	MMA8X5X_PULSE_SRC,
	MMA8X5X_PULSE_THSX,
	MMA8X5X_PULSE_THSY,
	MMA8X5X_PULSE_THSZ,
	MMA8X5X_PULSE_TMLT,
	MMA8X5X_PULSE_LTCY,
	MMA8X5X_PULSE_WIND,

	MMA8X5X_ASLP_COUNT,
	MMA8X5X_CTRL_REG1,
	MMA8X5X_CTRL_REG2,
	MMA8X5X_CTRL_REG3,
	MMA8X5X_CTRL_REG4,
	MMA8X5X_CTRL_REG5,

	MMA8X5X_OFF_X,
	MMA8X5X_OFF_Y,
	MMA8X5X_OFF_Z,

	MMA8X5X_REG_END,
};

enum {
	STANDBY = 0,
	ACTIVED,
};
enum {
	MODE_2G = 0,
	MODE_4G,
	MODE_8G,
};

struct mma8x5x_data_axis {
	short x;
	short y;
	short z;
};
struct mma8x5x_data {
	struct i2c_client *client;
	struct input_dev *idev;
	atomic_t active;
	atomic_t delay;
	atomic_t position;
	u8 chip_id;
};
static struct mma8x5x_data *g_mma8x5x_data = NULL;
static char *mma8x5x_names[] = {
	"mma8451",
	"mma8452",
	"mma8453",
	"mma8652",
	"mma8653",
};
static int mma8x5x_position_setting[8][3][3] = {
	{ { 0,	-1, 0  }, { 1,	0,  0	   }, { 0, 0, 1	     } },
	{ { -1, 0,  0  }, { 0,	-1, 0	   }, { 0, 0, 1	     } },
	{ { 0,	1,  0  }, { -1, 0,  0	   }, { 0, 0, 1	     } },
	{ { 1,	0,  0  }, { 0,	1,  0	   }, { 0, 0, 1	     } },

	{ { 0,	-1, 0  }, { -1, 0,  0	   }, { 0, 0, -1     } },
	{ { -1, 0,  0  }, { 0,	1,  0	   }, { 0, 0, -1     } },
	{ { 0,	1,  0  }, { 1,	0,  0	   }, { 0, 0, -1     } },
	{ { 1,	0,  0  }, { 0,	-1, 0	   }, { 0, 0, -1     } },
};

static int mma8x5x_data_convert(struct mma8x5x_data *pdata,
		struct mma8x5x_data_axis *axis_data)
{
	short rawdata[3], data[3];
	int i, j;
	int position = atomic_read(&pdata->position);

	if (position < 0 || position > 7)
		position = 0;
	rawdata[0] = axis_data->x;
	rawdata[1] = axis_data->y;
	rawdata[2] = axis_data->z;
	for (i = 0; i < 3; i++) {
		data[i] = 0;
		for (j = 0; j < 3; j++)
			data[i] += rawdata[j] * mma8x5x_position_setting[position][i][j];
	}
	axis_data->x = data[0];
	axis_data->y = data[1];
	axis_data->z = data[2];
	return 0;
}
static int mma8x5x_motion_detect_cfg(struct i2c_client *client,u8 threshold,u8 debounce_count)
{
	int result;
	u8 val,ctrl_reg1;
	ctrl_reg1 = i2c_smbus_read_byte_data(client, MMA8X5X_CTRL_REG1);
	result = i2c_smbus_write_byte_data(client, MMA8X5X_CTRL_REG1, (ctrl_reg1 & ~0x01));// force to standby
	if (result < 0)
		goto out;
	result = i2c_smbus_write_byte_data(client, MMA8X5X_FF_MT_CFG, 0xf8);
	if(result < 0)
		goto out;
		
	result = i2c_smbus_write_byte_data(client, MMA8X5X_FF_MT_THS, threshold);
		if(result < 0)
			goto out;
	result = i2c_smbus_write_byte_data(client, MMA8X5X_FF_MT_COUNT, debounce_count);
		if(result < 0)
			goto out;
		
	val = i2c_smbus_read_byte_data(client, MMA8X5X_CTRL_REG5);
	result = i2c_smbus_write_byte_data(client, MMA8X5X_CTRL_REG5, val | (0x01 << 2)); //motion detect enable
	if(result < 0)
		goto out;

	val = i2c_smbus_read_byte_data(client, MMA8X5X_CTRL_REG4);
	result = i2c_smbus_write_byte_data(client, MMA8X5X_CTRL_REG4, val | (0x01 << 2));//motion detect route to pin1
	if(result < 0)
		goto out;
	
	i2c_smbus_write_byte_data(client, MMA8X5X_CTRL_REG1, ctrl_reg1); //restore sensor standby/active mode
	return 0;
out:
	dev_err(&client->dev, "error when set mma8x5x motion detect configure:(%d)", result);
	return result;
}
static int mma8x5x_device_init(struct i2c_client *client)
{
	int result;
	u8 val;
	struct mma8x5x_data *pdata = i2c_get_clientdata(client);
	
	result = i2c_smbus_write_byte_data(client, MMA8X5X_CTRL_REG1, 0);
	if (result < 0)
		goto out;
	
	result = i2c_smbus_write_byte_data(client, MMA8X5X_XYZ_DATA_CFG, MODE_2G);
	if (result < 0)
		goto out;

	if(client->irq){
		val = 0x01;
		result = i2c_smbus_write_byte_data(client, MMA8X5X_CTRL_REG5, 0x01);
		if(result < 0)
			goto out;

		val = 0x01;
		result = i2c_smbus_write_byte_data(client, MMA8X5X_CTRL_REG4, 0x01);
		if(result < 0)
			goto out;
	}
	atomic_set(&pdata->active,STANDBY);
	return 0;
out:
	dev_err(&client->dev, "error when init mma8x5x:(%d)", result);
	return result;

}

static int mma8x5x_change_mode(struct i2c_client *client, int mode)
{
	u8 val;
	int ret;
	val = i2c_smbus_read_byte_data(client, MMA8X5X_CTRL_REG1);
	if(mode == ACTIVED)
		val |= 0x01;		
	 else
		val &= (~0x01);
	ret = i2c_smbus_write_byte_data(client, MMA8X5X_CTRL_REG1,val); 
	return ret;
}
static int mma8x5x_set_delay(struct i2c_client *client, int delay)
{
	u8 val;
	val = i2c_smbus_read_byte_data(client, MMA8X5X_CTRL_REG1);
	i2c_smbus_write_byte_data(client, MMA8X5X_CTRL_REG1, (val & ~0x01)); //set sensor standby
	val &= ~(0x7 << 3);
	if(delay <= 5)
		val |= 0x02 << 3;
	else if(delay <= 10)
		val |= 0x03 << 3;
	else if(delay <= 20)
		val |= 0x04 << 3;
    else if(delay <= 80)
		val |= 0x05 << 3;
	else if(delay <= 200)
		val |= 0x06 << 3;
	else if(delay <= 640)
		val |= 0x06 << 3;
	else
		val |= 0x03 << 3; 
	i2c_smbus_write_byte_data(client, MMA8X5X_CTRL_REG1, val); //set sensor standby
	return 0;
}
static int mma8x5x_read_data(struct mma8x5x_data *pdata,
		struct mma8x5x_data_axis *data)
{
    struct i2c_client * client = pdata->client;

	u8 tmp_data[MMA8X5X_BUF_SIZE];
	int ret;
	ret = i2c_smbus_read_i2c_block_data(client, MMA8X5X_OUT_X_MSB,
									MMA8X5X_BUF_SIZE, tmp_data);
	if (ret < MMA8X5X_BUF_SIZE) {
		dev_err(&client->dev, "i2c block read failed\n");
		return -EIO;
	}
	data->x = ((tmp_data[0] << 8) & 0xff00) | tmp_data[1];
	data->y = ((tmp_data[2] << 8) & 0xff00) | tmp_data[3];
	data->z = ((tmp_data[4] << 8) & 0xff00) | tmp_data[5];
	return 0;
}

//mma8x5x miscdevice
static long mma8x5x_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
	struct mma8x5x_data *pdata = file->private_data;
	void __user *argp = (void __user *)arg;	
    long ret = 0;
	short sdata[3];
	int enable;
	int delay;
	int index;
	struct mma8x5x_data_axis data;
	if(!pdata){
		printk(KERN_ERR "MMA8X5X struct datt point is NULL.");
		return -EFAULT;
	}
	switch (cmd) {
		case SENSOR_GET_MODEL_NAME:
			index = (pdata->chip_id - MMA8451_ID) >> 4;
			if(copy_to_user(argp,mma8x5x_names[index],strlen(mma8x5x_names[index]) +1))
			{
				printk(KERN_ERR "SENSOR_GET_MODEL_NAME copy_to_user failed.");
				ret = -EFAULT;
			}
			break;
		case SENSOR_GET_POWER_STATUS:
			enable = atomic_read(&pdata->active);
			if(copy_to_user(argp,&enable,sizeof(int)))
			{
				printk(KERN_ERR "SENSOR_SET_POWER_STATUS copy_to_user failed.");
				ret = -EFAULT;
			}
			break;
		case SENSOR_SET_POWER_STATUS:
			if(copy_from_user(&enable,argp,sizeof(int)))
			{
				printk(KERN_ERR "SENSOR_SET_POWER_STATUS copy_to_user failed.");
				ret = -EFAULT;
			}
			if(pdata->client){
				ret = mma8x5x_change_mode(pdata->client,enable? ACTIVED : STANDBY);
				if(!ret)
					atomic_set(&pdata->active,enable);
			}
			break;
		case SENSOR_GET_DELAY_TIME:
			delay = atomic_read(&pdata->delay);
			if(copy_to_user(argp, &delay, sizeof(delay)))
			{
				printk(KERN_ERR "SENSOR_GET_DELAY_TIME copy_to_user failed.");
				return -EFAULT;
			}
			break;
		case SENSOR_SET_DELAY_TIME:
			if(copy_from_user(&delay,argp,sizeof(int)));
			{
				printk(KERN_ERR "SENSOR_GET_DELAY_TIME copy_to_user failed.");
				ret = -EFAULT;
			}
			if(pdata->client && delay > 0 && delay <= 500){
				ret = mma8x5x_set_delay(pdata->client,delay);
				if(!ret)
					atomic_set(&pdata->delay,delay);
			}
			break;
		case SENSOR_GET_RAW_DATA:
			ret = mma8x5x_read_data(pdata,&data);
			if(!ret){
				mma8x5x_data_convert(pdata,&data);
				sdata[0] = data.x;
				sdata[1] = data.y;
				sdata[2] = data.z;
				if(copy_to_user(argp,sdata,sizeof(sdata)))
				{
					printk(KERN_ERR "SENSOR_GET_RAW_DATA copy_to_user failed.");
					ret = -EFAULT;
				}
			}
			break;
		default:
			ret = -1;
	}
	return ret;
}

static int mma8x5x_open(struct inode *inode, struct file *file)
{
	file->private_data = g_mma8x5x_data;
	return nonseekable_open(inode, file);
}

static int mma8x5x_release(struct inode *inode, struct file *file)
{
	/* note: releasing the wdt in NOWAYOUT-mode does not stop it */
	return 0;
}

static const struct file_operations mma8x5x_fops = {
	.owner = THIS_MODULE,
	.open = mma8x5x_open,
	.release = mma8x5x_release,
	.unlocked_ioctl = mma8x5x_ioctl,
};

static struct miscdevice mma8x5x_device = {
	.minor = MISC_DYNAMIC_MINOR,
	.name = "FreescaleAccelerometer",
	.fops = &mma8x5x_fops,
};

static ssize_t mma8x5x_enable_show(struct device *dev,
				   struct device_attribute *attr, char *buf)
{
	struct mma8x5x_data *pdata = g_mma8x5x_data;
	int enable = 0;
	enable = atomic_read(&pdata->active);
	return sprintf(buf, "%d\n", enable);
}

static ssize_t mma8x5x_enable_store(struct device *dev,
				    struct device_attribute *attr,
				    const char *buf, size_t count)
{
	struct mma8x5x_data *pdata = g_mma8x5x_data;
	struct i2c_client *client = pdata->client;
	int ret;
	unsigned long enable;
	enable = simple_strtoul(buf, NULL, 10);
	enable = (enable > 0) ? 1 : 0;
	ret = mma8x5x_change_mode(client,(enable > 0 ? ACTIVED : STANDBY));
	if (!ret) {
		atomic_set(&pdata->active,enable);
		printk(KERN_INFO"mma enable setting active \n");
	}
	return count;
}

static ssize_t mma8x5x_poll_delay_show(struct device *dev,
				   struct device_attribute *attr, char *buf)
{
	struct mma8x5x_data *pdata = g_mma8x5x_data;
	int delay = 0;
	delay = atomic_read(&pdata->delay);
	return sprintf(buf, "%d\n", delay);
}

static ssize_t mma8x5x_poll_delay_store(struct device *dev,
				    struct device_attribute *attr,
				    const char *buf, size_t count)
{
	struct mma8x5x_data *pdata = g_mma8x5x_data;
	struct i2c_client *client = pdata->client;
	int ret;
	int delay;
	delay = simple_strtoul(buf, NULL, 10);
	ret = mma8x5x_set_delay(client,delay);
	if(!ret)
		atomic_set(&pdata->delay, delay);
	return count;
}

static ssize_t mma8x5x_position_show(struct device *dev,
				     struct device_attribute *attr, char *buf)
{
	struct mma8x5x_data *pdata = g_mma8x5x_data;
	int position = 0;
	position = atomic_read(&pdata->position);
	return sprintf(buf, "%d\n", position);
}

static ssize_t mma8x5x_position_store(struct device *dev,
				      struct device_attribute *attr,
				      const char *buf, size_t count)
{
	struct mma8x5x_data *pdata = g_mma8x5x_data;
	int position;
	position = simple_strtoul(buf, NULL, 10);
	atomic_set(&pdata->position,position);
	return count;
}
static ssize_t mma8x5x_data_show(struct device *dev,
				     struct device_attribute *attr, char *buf)
{
	struct mma8x5x_data *pdata = g_mma8x5x_data;
	int ret = 0;
	struct mma8x5x_data_axis data;
	ret = mma8x5x_read_data(pdata,&data);
	if(!ret)
		mma8x5x_data_convert(pdata,&data);
	return sprintf(buf, "%d,%d,%d\n",data.x,data.y,data.z);
}

static ssize_t mma8x5x_motion_detect_show(struct device *dev,
				     struct device_attribute *attr, char *buf)
{
	struct mma8x5x_data *pdata = g_mma8x5x_data;
	struct i2c_client *client = pdata->client;
	u8 threshold, dbounce;
	threshold = i2c_smbus_read_byte_data(client,MMA8X5X_FF_MT_THS);
	dbounce =  i2c_smbus_read_byte_data(client,MMA8X5X_FF_MT_COUNT);
	return sprintf(buf, "threshold %d,debounce %d\n", threshold,dbounce);
}

static ssize_t mma8x5x_motion_detect_store(struct device *dev,
				      struct device_attribute *attr,
				      const char *buf, size_t count)
{
	struct mma8x5x_data *pdata = g_mma8x5x_data;
	struct i2c_client *client = pdata->client;
	int threshold, dbounce;
	sscanf(buf,"%d,%d",&threshold,&dbounce);
	mma8x5x_motion_detect_cfg(client,threshold,dbounce);
	return count;
}

static DEVICE_ATTR(enable, 0666, mma8x5x_enable_show, mma8x5x_enable_store);

static DEVICE_ATTR(poll_delay, 0666,mma8x5x_poll_delay_show, mma8x5x_poll_delay_store);

static DEVICE_ATTR(position, 0666,mma8x5x_position_show, mma8x5x_position_store);

static DEVICE_ATTR(data, 0666,mma8x5x_data_show, NULL);

static DEVICE_ATTR(motion_detect, 0666,mma8x5x_motion_detect_show, mma8x5x_motion_detect_store);

static struct attribute *mma8x5x_attributes[] = {
	&dev_attr_enable.attr,
	&dev_attr_poll_delay.attr,
	&dev_attr_position.attr,
	&dev_attr_data.attr,
	&dev_attr_motion_detect.attr,
	NULL
};

static const struct attribute_group mma8x5x_attr_group = {
	.attrs	= mma8x5x_attributes,
};


static irqreturn_t mma8x5x_irq_handler(int irq, void *dev)
{
	int ret;
	u8 int_src;
	struct mma8x5x_data *pdata = (struct mma8x5x_data *)dev;
	struct mma8x5x_data_axis data;
	int_src = i2c_smbus_read_byte_data(pdata->client,MMA8X5X_INT_SOURCE);
	if(int_src & 0x01 ){ //data ready interrupt
		ret = mma8x5x_read_data(pdata,&data);
		if(!ret){
			mma8x5x_data_convert(pdata,&data);
			input_report_abs(pdata->idev, ABS_X, data.x);
			input_report_abs(pdata->idev, ABS_Y, data.y);
			input_report_abs(pdata->idev, ABS_Z, data.z);
			input_sync(pdata->idev);
		}
		
	}
	if(int_src & (0x01 << 2) ){ //motion detect
		i2c_smbus_read_byte_data(pdata->client,MMA8X5X_FF_MT_SRC); //clear ev flag
		input_report_rel(pdata->idev,REL_X, 1);
		input_sync(pdata->idev);
	}

	return IRQ_HANDLED;
}


static int __devinit mma8x5x_probe(struct i2c_client *client,
				   const struct i2c_device_id *id)
{
	int result, chip_id;
	struct mma8x5x_data *pdata;
	struct i2c_adapter *adapter;
	
	adapter = to_i2c_adapter(client->dev.parent);
	result = i2c_check_functionality(adapter,
					 I2C_FUNC_SMBUS_BYTE |
					 I2C_FUNC_SMBUS_BYTE_DATA);
	if (!result)
		goto err_out;

	chip_id = i2c_smbus_read_byte_data(client, MMA8X5X_WHO_AM_I);

	
	if (chip_id != MMA8451_ID && chip_id != MMA8452_ID && chip_id != MMA8453_ID && chip_id != MMA8652_ID && chip_id != MMA8653_ID) {
		dev_err(&client->dev, "read sensor who am i (0x%x)error !\n",chip_id);
		result = -EINVAL;
		goto err_out;
	}
	pdata = kzalloc(sizeof(struct mma8x5x_data), GFP_KERNEL);
	if (!pdata) {
		result = -ENOMEM;
		dev_err(&client->dev, "alloc data memory error!\n");
		goto err_out;
	}
	/* Initialize the MMA8X5X chip */
	g_mma8x5x_data = pdata;
	pdata->client = client;
	pdata->chip_id = chip_id;
	atomic_set(&pdata->delay,MMA8X5X_DELAY_DEFAULT);
	atomic_set(&pdata->position,MMA8X5X_POSITION_DEFAULT);
	i2c_set_clientdata(client, pdata);
	result = misc_register(&mma8x5x_device);
	if (result != 0) {
		printk(KERN_ERR "register acc miscdevice error");
		goto err_regsiter_misc;
	}
	
	result = sysfs_create_group(&mma8x5x_device.this_device->kobj, &mma8x5x_attr_group);
	if (result) {
		dev_err(&client->dev, "create device file failed!\n");
		result = -EINVAL;
		goto err_create_sysfs;
	}
	/*create data  input device*/
	pdata->idev = input_allocate_device();
	if (!pdata->idev) {
		result = -ENOMEM;
		dev_err(&client->dev, "alloc mma8x5x input device failed!\n");
		goto err_alloc_input_device;
	}
	pdata->idev->name = "FreescaleAccelerometer";
	pdata->idev->id.bustype = BUS_I2C;
	pdata->idev->evbit[0] = BIT_MASK(EV_ABS)|BIT_MASK(EV_REL);
	input_set_abs_params(pdata->idev, ABS_X, -0x7fff, 0x7fff, 0, 0);
	input_set_abs_params(pdata->idev, ABS_Y, -0x7fff, 0x7fff, 0, 0);
	input_set_abs_params(pdata->idev, ABS_Z, -0x7fff, 0x7fff, 0, 0);
	pdata->idev->relbit[0] = BIT_MASK(REL_X);
	result = input_register_device(pdata->idev);
	if (result) {
		dev_err(&client->dev, "register mma8x5x input device failed!\n");
		goto err_register_input_device;
	}
	if(client->irq){
		result= request_threaded_irq(client->irq,NULL, mma8x5x_irq_handler,
				  IRQF_TRIGGER_LOW | IRQF_ONESHOT, client->dev.driver->name, pdata);
		if (result < 0) {
			dev_err(&client->dev, "failed to register MMA8x5x irq %d!\n",
				client->irq);
			goto err_register_irq;
		}
	}
	mma8x5x_device_init(client);
	printk(KERN_INFO"mma8x5x device driver probe successfully\n");
	return 0;
err_register_irq:
	input_unregister_device(pdata->idev);
err_register_input_device:
	input_free_device(pdata->idev);
err_alloc_input_device:
	sysfs_remove_group(&mma8x5x_device.this_device->kobj, &mma8x5x_attr_group);
err_create_sysfs:
	misc_deregister(&mma8x5x_device);
err_regsiter_misc:
	kfree(pdata);
err_out:
	return result;
}
static int __devexit mma8x5x_remove(struct i2c_client *client)
{
	struct mma8x5x_data *pdata = i2c_get_clientdata(client);
	mma8x5x_change_mode(client,STANDBY);
	misc_deregister(&mma8x5x_device);
	if(pdata != NULL)
		kfree(pdata);
	return 0;
}

#ifdef CONFIG_PM_SLEEP
static int mma8x5x_suspend(struct device *dev)
{
	struct i2c_client *client = to_i2c_client(dev);
	struct mma8x5x_data *pdata = i2c_get_clientdata(client);

	if (atomic_read(&pdata->active))		
		mma8x5x_change_mode(client,STANDBY);		
	return 0;
}

static int mma8x5x_resume(struct device *dev)
{
	struct i2c_client *client = to_i2c_client(dev);
	struct mma8x5x_data *pdata = i2c_get_clientdata(client);
	
	if (atomic_read(&pdata->active)) 
		mma8x5x_change_mode(client,ACTIVED);
	return 0;
}
#endif

static const struct i2c_device_id mma8x5x_id[] = {
	{ "mma8x5x", 0 },
	{ }
};
MODULE_DEVICE_TABLE(i2c, mma8x5x_id);

static SIMPLE_DEV_PM_OPS(mma8x5x_pm_ops, mma8x5x_suspend, mma8x5x_resume);
static struct i2c_driver mma8x5x_driver = {
	.class		= I2C_CLASS_HWMON,
	.driver		= {
		.name	= "mma8x5x",
		.owner	= THIS_MODULE,
		.pm	= &mma8x5x_pm_ops,
	},
	.probe		= mma8x5x_probe,
	.remove		= __devexit_p(mma8x5x_remove),
	.id_table	= mma8x5x_id,
};

static int __init mma8x5x_init(void)
{
	/* register driver */
	int res;

	res = i2c_add_driver(&mma8x5x_driver);
	if (res < 0) {
		printk(KERN_INFO "add mma8x5x i2c driver failed\n");
		return -ENODEV;
	}
	return res;
}

static void __exit mma8x5x_exit(void)
{
	i2c_del_driver(&mma8x5x_driver);
}

MODULE_AUTHOR("Freescale Semiconductor, Inc.");
MODULE_DESCRIPTION("MMA8X5X 3-Axis Gyrosope Sensor driver");
MODULE_LICENSE("GPL");

module_init(mma8x5x_init);
module_exit(mma8x5x_exit);

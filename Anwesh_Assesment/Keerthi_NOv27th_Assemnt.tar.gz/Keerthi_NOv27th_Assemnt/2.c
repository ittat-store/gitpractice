#include <stdio.h>
 
int main()
{ long n,x;
   scanf("%ld",&n);
   x=n/2;
   printf("%ld",(x+1)*(n-x));
    return 0;
}

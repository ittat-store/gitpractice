This is the sample code of completion in Linux. You can find the explation of these source code in below mentioned website.
https://embetronicx.com/tutorials/linux/device-drivers/completion-in-linux/

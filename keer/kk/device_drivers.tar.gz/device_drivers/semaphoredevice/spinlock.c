#include<linux/module.h>
#include<linux/kernel.h>
#include<linux/fs.h>
#include<linux/cdev.h>
#include<linux/semaphore.h>
#include<linux/uaccess.h>

struct fake_device
{
	char data[100];
	struct semaphore sem;
}virtual_device;

struct cdev *mcdev;
int major_number;
int ret;

dev_t dev_num;

#define DEVICE_NAME "fakedevice"


int device_open(struct inode *inode,struct file *filp)
{
	if(down_interruptible(&virtual_device.sem)!=0)
	{
		printk(KERN_ALERT "could not lock device during open\n");
		return -1;
	}

	printk(KERN_INFO "opened device\n");
	return 0;
}

// called when user wants to get info from the device
ssize_t device_read(struct file *filp,char * bufstoredata,size_t bufcount,loff_t *curoffset)
{
	printk(KERN_INFO "reading from device\n");
	ret=copy_to_user(bufstoredata,virtual_device.data,bufcount);
	return ret;
}

//when user wants to send info to the device
ssize_t device_write(struct file *filp,const char * bufstoredata,size_t bufcount,loff_t *curoffset)
{
	printk(KERN_INFO "writing to device\n");
	ret=copy_from_user(virtual_device.data,bufstoredata,bufcount);
	return ret;
}


int device_close(struct inode *inode,struct file *filp)
{
	up(&virtual_device.sem);// we release the mutex that we obtain at open,now allowing other process to use the device now
	printk(KERN_INFO "closed device\n");
	return 0;
}


struct file_operations fops={
        .owner=THIS_MODULE,
        .open=device_open,
        .release=device_close,
        .write=device_write,
        .read=device_read,
};




static int driver_entry(void)
{
	ret=alloc_chrdev_region(&dev_num,0,1,DEVICE_NAME);
	if(ret<0)
	{
		printk(KERN_ALERT "failed to allocate a major number\n");
			return ret;
	}
	major_number=MAJOR(dev_num);
	printk(KERN_INFO "major number is %d\n",major_number);
	printk(KERN_INFO "USE MKNOD FOR DEVICE FILE  %s, major number %d\n",DEVICE_NAME,major_number);
	mcdev=cdev_alloc();
	mcdev->ops=&fops;
	mcdev->owner=THIS_MODULE;
        // add cdev to kernel
	ret=cdev_add(mcdev,dev_num,1);
	if(ret<0)
	{
		printk(KERN_ALERT "unable to add cedevto kernel\n");
			return ret;
	}
	sema_init(&virtual_device.sem,1); //initial value one
	return 0;
}

static void driver_exit(void)
{
	cdev_del(mcdev);
	unregister_chrdev_region(dev_num,1);
	printk(KERN_ALERT "unloaded module\n");
}

module_init(driver_entry);
module_exit(driver_exit);

MODULE_LICENSE("GPL");


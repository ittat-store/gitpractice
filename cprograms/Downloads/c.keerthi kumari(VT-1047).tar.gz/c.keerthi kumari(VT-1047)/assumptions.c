first i created the two threads
and using thread1 i opened the file and by using readword function i read the number of words in thread1
and nxt signal given to thread2 in that i compared the commandline string and word
if they are equal then reverse of that word is written using revstring function
last i put the revstring in file 

